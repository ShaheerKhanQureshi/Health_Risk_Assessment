const nodemailer = require('nodemailer');

// Create a transporter object using your email service's SMTP credentials
const transporter = nodemailer.createTransport({
  service: 'gmail',  // Use any email service here
  auth: {
    user: process.env.EMAIL_USER,  // Your email username
    pass: process.env.EMAIL_PASS,  // Your email password
  },
});

// Function to send emails
const sendEmail = async (to, subject, htmlContent) => {
  try {
    const info = await transporter.sendMail({
      from: process.env.EMAIL_USER,  // sender address
      to,  // recipient address
      subject,  // subject line
      html: htmlContent,  // HTML body
    });

    console.log('Email sent: ' + info.response);
    return info;
  } catch (error) {
    console.error('Error sending email:', error);
    throw new Error('Error sending email');
  }
};

module.exports = sendEmail;

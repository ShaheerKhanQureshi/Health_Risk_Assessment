// Utility function to validate user_id
const validateUserId = (userId) => {
    return Number.isInteger(parseInt(userId));
  };
  
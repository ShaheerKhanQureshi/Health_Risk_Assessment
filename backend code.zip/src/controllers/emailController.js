const nodemailer = require('nodemailer');

// Create transporter for sending emails
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'qshaheerkhan@gmail.com', 
    pass: 'utbiglxxydbulnuw',   

  },
});

// Function to send company creation email
const sendCompanyEmail = async (email, companyFormLink) => {
  const mailOptions = {
    from: 'your-email@gmail.com',
    to: email,
    subject: 'Welcome to Our Platform!',
    html: `<h1>Your Company URL is Ready</h1>
           <p>Click <a href="${companyFormLink}">${companyFormLink}</a> to access your company's form.</p>`,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error("Error sending company email:", error);
    throw new Error('Failed to send company email');
  }
};

// Function to send assessment email
const sendAssessmentEmail = async (employeeEmail, assessmentResults) => {
  const mailOptions = {
    from: 'your-email@gmail.com',
    to: employeeEmail,
    subject: 'Your Health Assessment Results',
    html: `<h1>Your Health Assessment</h1>
           <p>Your BMI: ${assessmentResults.bmi}</p>
           <p>Your total score: ${assessmentResults.score}</p>
           <p>Keep up the good work!</p>`,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error("Error sending assessment email:", error);
    throw new Error('Failed to send assessment email');
  }
};

module.exports = {
  sendCompanyEmail,
  sendAssessmentEmail,
};



// const sendEmail = require('../config/nodemailer');

// // 1. Send email when company is created
// const sendCompanyCreationEmail = async (companyName, companySlug, companyEmail) => {
//   const companyLink = `${process.env.BASE_URL}/company/${companySlug}`;
//   const htmlContent = `
//     <html>
//       <body>
//         <h1>Congratulations, ${companyName}!</h1>
//         <p>Your company has been successfully created!</p>
//         <p>To access your company’s page, click the link below:</p>
//         <a href="${companyLink}">${companyLink}</a>
//       </body>
//     </html>
//   `;
//   await sendEmail(companyEmail, `Company ${companyName} Created`, htmlContent);
// };

// // 2. Send email when user submits their health form
// const sendUserSubmissionEmail = async (userEmail, userData) => {
//   const { userName, bmi, marks, bp, diabetesRisk, cholesterol } = userData;
//   const htmlContent = `
//     <html>
//       <body>
//         <h1>Hi ${userName},</h1>
//         <p>Thank you for submitting your health form! Here are your details:</p>
//         <ul>
//           <li>BMI: ${bmi}</li>
//           <li>Marks: ${marks}</li>
//           <li>Blood Pressure: ${bp}</li>
//           <li>Diabetes Risk: ${diabetesRisk}</li>
//           <li>Cholesterol: ${cholesterol}</li>
//         </ul>
//       </body>
//     </html>
//   `;
//   await sendEmail(userEmail, 'Your Health Report', htmlContent);
// };

// // 3. Send email with company report
// const sendCompanyReportEmail = async (companyEmail, companyName, reportLink) => {
//   const htmlContent = `
//     <html>
//       <body>
//         <h1>${companyName} Employee Health Report</h1>
//         <p>Dear ${companyName},</p>
//         <p>Here is the health report for your employees. Please find the details below:</p>
//         <p><a href="${reportLink}">Click here to download the report</a></p>
//       </body>
//     </html>
//   `;
//   await sendEmail(companyEmail, `${companyName} - Employee Health Report`, htmlContent);
// };

// module.exports = {
//   sendCompanyCreationEmail,
//   sendUserSubmissionEmail,
//   sendCompanyReportEmail,
// };

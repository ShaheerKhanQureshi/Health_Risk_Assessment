const nodemailer = require('nodemailer');
const db = require('../config/db');

// Helper function to send emails
const sendEmail = async (to, subject, content) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'qshaheerkhan@gmail.com', // Use a more secure method like an App Password here
      pass: 'utbiglxxydbulnuw', // Use an App Password instead of your regular password
    },
  });

  const mailOptions = {
    from: 'qshaheerkhan@gmail.com',
    to,
    subject,
    html: content,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent:', info.response);
  } catch (error) {
    console.error('Error sending email:', error);
    throw new Error('Failed to send email');
  }
};

// Helper function to calculate age from date of birth
const calculateAge = (dob) => {
  const birthDate = new Date(dob);
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const month = today.getMonth();
  
  if (month < birthDate.getMonth() || (month === birthDate.getMonth() && today.getDate() < birthDate.getDate())) {
    age--;
  }

  return age;
};

// Helper function to calculate BMI
const calculateBMI = (weight, height) => {
  const heightInMeters = height / 100;
  return (weight / (heightInMeters * heightInMeters)).toFixed(2);
};

// Helper function to categorize BMI
const getBMICategory = (bmi) => {
  if (bmi < 18.5) return 'Below Normal';
  if (bmi < 25) return 'Normal';
  if (bmi < 30) return 'Overweight';
  return 'Obesity';
};

// Helper function to extract blood pressure data
const getBloodPressureData = (healthAssessment) => {
  const bpData = healthAssessment?.find(item => item.subHeading === 'Personal Medical History')
    ?.questions?.find(q => q.questionId === 'PMH14' && q.response);

  if (!bpData || !bpData.response) {
    return { bpValue: null, bpInterpretation: 'Unknown' };
  }

  const response = bpData.response.trim().toLowerCase();
  const bpCategories = {
    '140 mmhg or higher / 90 mmhg or higher': { bpValue: '140+/90+', bpInterpretation: 'High Blood Pressure (Hypertension Stage 2)' },
    '130-139 mm hg / 85-89 mmhg': { bpValue: '130-139 / 85-89', bpInterpretation: 'High Blood Pressure (Hypertension Stage 1)' },
    '120-129 mmhg / 80-84 mmhg': { bpValue: '120-129 / 80-84', bpInterpretation: 'Elevated Blood Pressure' },
    '80-119 mmhg / 60-79 mmhg': { bpValue: 'Normal', bpInterpretation: 'Normal Blood Pressure' },
    'less than 80 mmhg / less than 60 mmhg': { bpValue: 'Low', bpInterpretation: 'Low Blood Pressure' },
    'i don\'t know': { bpValue: 'Unknown', bpInterpretation: 'Blood Pressure Unknown' }
  };

  return bpCategories[response] || { bpValue: null, bpInterpretation: 'Unknown' };
};

// Helper functions to extract glucose and cholesterol levels (add these functions if not already implemented)
const getGlucoseLevelData = (healthAssessment) => {
  const glucoseData = healthAssessment?.find(item => item.subHeading === 'Diabetes Risk')
    ?.questions?.find(q => q.questionId === 'DR1' && q.response);
  return glucoseData ? glucoseData.response : 'Unknown';
};

const getCholesterolLevelData = (healthAssessment) => {
  const cholesterolData = healthAssessment?.find(item => item.subHeading === 'Cholesterol Risk')
    ?.questions?.find(q => q.questionId === 'CR1' && q.response);
  return cholesterolData ? cholesterolData.response : 'Unknown';
};

// Main function to get user health report and send email
const getUserHealthReport = async (req, res) => {
  const { company_slug } = req.params;
  const { assessment_id } = req.query;

  // Validate assessment_id
  if (!assessment_id || isNaN(assessment_id)) {
    return res.status(400).json({ success: false, message: 'Invalid assessment_id' });
  }

  try {
    // Fetch data from database
    const query = 'SELECT employee_info, health_assessment FROM assessment_response WHERE assessment_id = ? AND company_slug = ?;';
    const [results] = await db.execute(query, [assessment_id, company_slug]);

    if (results.length === 0) {
      return res.status(404).json({ success: false, message: 'No data found for the provided assessment_id' });
    }

    // Parse and destructure employee and health assessment data
    const employeeInfo = JSON.parse(results[0].employee_info);
    const healthAssessment = JSON.parse(results[0].health_assessment);

    const { dob, height, weight, email, name } = employeeInfo;
    const age = calculateAge(dob);
    const bmi = calculateBMI(weight, height);
    const bmiCategory = getBMICategory(bmi);
    const { bpValue, bpInterpretation } = getBloodPressureData(healthAssessment);
    const glucose_level = getGlucoseLevelData(healthAssessment);
    const cholesterol_level = getCholesterolLevelData(healthAssessment);

    // Construct the email content
    const emailContent = `
      <h1>Health Assessment Report for ${name}</h1>
      <p><strong>Age:</strong> ${age}</p>
      <p><strong>BMI:</strong> ${bmi} (${bmiCategory})</p>
      <p><strong>Blood Pressure:</strong> ${bpValue} - ${bpInterpretation}</p>
      <p><strong>Glucose Level:</strong> ${glucose_level}</p>
      <p><strong>Cholesterol Level:</strong> ${cholesterol_level}</p>
    `;

    // Send the email
    await sendEmail(email, 'Your Health Assessment Report', emailContent);

    // Respond to the client
    return res.json({ success: true, message: 'Assessment submitted and email sent successfully!' });

  } catch (err) {
    console.error('Error in getUserHealthReport:', err.message);
    return res.status(500).json({ success: false, message: 'An error occurred while fetching user health report' });
  }
};

module.exports = {
  getUserHealthReport,
};

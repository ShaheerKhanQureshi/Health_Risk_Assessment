const db = require("../config/db");
const logger = require("../utils/logger");
const puppeteer = require("puppeteer");
const path = require("path");

const calculateBMI = (employees) => {
  const bmiData = {
    "Below-Normal-Weight": 0,
    "Normal-Weight": 0,
    "Overweight": 0,
    "Class-I-Obesity": 0,
    "Class-II-Obesity": 0,
    "Class-III-Obesity": 0,
  };

  employees.forEach((emp) => {
    const { weight, height } = JSON.parse(emp.employee_info);
    if (weight && height) {
      const bmi = weight / Math.pow(height / 100, 2);
      let category = "Below-Normal-Weight";
      if (bmi >= 18.5 && bmi <= 24.9) category = "Normal-Weight";
      else if (bmi >= 25 && bmi <= 29.9) category = "Overweight";
      else if (bmi >= 30 && bmi <= 34.9) category = "Class-I-Obesity";
      else if (bmi >= 35 && bmi <= 39.9) category = "Class-II-Obesity";
      else if (bmi >= 40) category = "Class-III-Obesity";
      bmiData[category]++;
    }
  });

  return bmiData;
};


// const calculateConditionPrevalence = (employees) => {
//   const conditions = {
//     "Rheumatoid Arthritis": 0,
//     "Diabetes": 0,
//     "Hypertension (High BP)": 0,
//     "Osteoarthritis": 0,
//     "Gout": 0,
//     "Anemia": 0,
//     "High Cholesterol": 0,
//     "Fibromyalgia": 0,
//     "Thyroid Disease": 0,
//     "Cardiovascular Disease (heart disease)": 0,
//     "Asthma": 0,
//     "Osteoporosis": 0,
//     "Chronic Kidney Disease": 0,
//     "COPD / Lung Disease": 0,
//     "Urogenital Disease": 0,
//     "Metabolic Disorder": 0,
//     "Stroke": 0,
//     "Cancer": 0,
//     "Genetic Disorder": 0,
//     "Myocardial Infarction": 0,
//     "Hepatitis B or C": 0,
//     "Tuberculosis": 0,
//     "Heart failure": 0,
//   };

//   employees.forEach((emp) => {
//     const healthData = JSON.parse(emp.health_assessment);
    
//     healthData.forEach((section) => {
//       if (section.subHeading === "Personal Medical History") {
//         section.questions.forEach((question) => {
//           if (question.questionId === "PMH3" || question.questionId === "PMH5" || question.questionId === "PMH7") {
//             const conditionsList = Array.isArray(question.response) ? question.response : [question.response];
            
//             // Log the conditions for each employee
//             console.log(`Conditions for employee: ${emp.id}:`, conditionsList);
  
//             conditionsList.forEach((condition) => {
//               if (conditions.hasOwnProperty(condition)) {
//                 conditions[condition]++;
//               }
//             });
//           }
//         });
//       }
//     });
//   });
  
//   const totalEmployees = employees.length;
//   Object.keys(conditions).forEach((condition) => {
//     conditions[condition] = ((conditions[condition] / totalEmployees) * 100).toFixed(2);
//   });

//   return conditions;
// };
const calculateConditionPrevalence = (employees) => {
  const conditions = {
    "Rheumatoid Arthritis": 0,
    "Diabetes": 0,
    "Hypertension (High BP)": 0,
    "Osteoarthritis": 0,
    "Gout": 0,
    "Anemia": 0,
    "High Cholesterol": 0,
    "Fibromyalgia": 0,
    "Thyroid Disease": 0,
    "Cardiovascular Disease (heart disease)": 0,
    "Asthma": 0,
    "Osteoporosis": 0,
    "Chronic Kidney Disease": 0,
    "COPD / Lung Disease": 0,
    "Urogenital Disease": 0,
    "Metabolic Disorder": 0,
    "Stroke": 0,
    "Cancer": 0,
    "Genetic Disorder": 0,
    "Myocardial Infarction": 0,
    "Hepatitis B or C": 0,
    "Tuberculosis": 0,
    "Heart failure": 0,
  };

  employees.forEach((emp) => {
    let healthData = [];
    try {
      healthData = JSON.parse(emp.health_assessment);
    } catch (e) {
      console.error(`Error parsing health_assessment for employee ${emp.id}: ${e.message}`);
      return;
    }

    healthData.forEach((section) => {
      if (section.subHeading === "Personal Medical History") {
        section.questions.forEach((question) => {
          if (question.questionId === "PMH3" || question.questionId === "PMH5" || question.questionId === "PMH7") {
            const conditionsList = Array.isArray(question.response) ? question.response : [question.response];

            conditionsList.forEach((condition) => {
              if (conditions.hasOwnProperty(condition)) {
                conditions[condition]++;
              }
            });
          }
        });
      }
    });
  });

  const totalEmployees = employees.length;
  Object.keys(conditions).forEach((condition) => {
    conditions[condition] = ((conditions[condition] / totalEmployees) * 100).toFixed(2);
  });

  return conditions;
};


const calculateRiskDistribution = (employees) => {
  // Define section total max scores
  const sectionMaxScores = {
    "Personal Health Habits": 50,
    "Personal Medical History": 156,
    "Women Health": 23,
    "Lifestyle and Diet": 31,
    "Mental and Emotional Health Risk": 40,
    "Occupational Health Risk": 50,
    "Burnout at Work": 50
  };

  // Initialize counters for section-wise distribution
  const sectionScores = {
    "Personal Health Habits": [],
    "Personal Medical History": [],
    "Women Health": [],
    "Lifestyle and Diet": [],
    "Mental and Emotional Health Risk": [],
    "Occupational Health Risk": [],
    "Burnout at Work": []
  };

  const riskCategories = {
    "Low Risk (0-80)": 0,
    "Moderate Risk (81-160)": 0,
    "High Risk (161-240)": 0,
    "Very High Risk (241-320)": 0,
    "Severe Risk (321-400)": 0
  };

  // Initialize total employee count
  const totalEmployees = employees.length;

  if (totalEmployees === 0) {
    return {
      sectionScores,
      riskCategories,
      totalEmployees
    };
  }

  // Process each employee's health assessment
  employees.forEach((emp) => {
    let healthAssessment;

    try {
      // Attempt to parse the health_assessment field
      healthAssessment = JSON.parse(emp.health_assessment);
    } catch (error) {
      console.error('Error parsing health_assessment for employee:', emp);
      return;
    }

    // Collect scores for each section
    healthAssessment.forEach((section) => {
      if (sectionScores[section.subHeading] && section.sectionScore != null) {
        sectionScores[section.subHeading].push(section.sectionScore);
      }
    });
  });

  // Calculate average score per section
  const sectionAverages = {};
  for (let section in sectionScores) {
    const scores = sectionScores[section];

    if (scores.length > 0) {
      const totalScore = scores.reduce((sum, score) => sum + score, 0);
      const averageScore = totalScore / scores.length;
      sectionAverages[section] = averageScore;
    } else {
      // If no data for this section, mark as null or N/A
      sectionAverages[section] = "N/A";
    }
  }

  // Calculate how many employees fall into each risk category based on average score for each section
  for (let section in sectionScores) {
    sectionScores[section].forEach((score) => {
      let category = '';
      if (score <= 80) {
        category = "Low Risk (0-80)";
      } else if (score <= 160) {
        category = "Moderate Risk (81-160)";
      } else if (score <= 240) {
        category = "High Risk (161-240)";
      } else if (score <= 320) {
        category = "Very High Risk (241-320)";
      } else {
        category = "Severe Risk (321-400)";
      }

      riskCategories[category]++;
    });
  }

  // Calculate percentage distribution for each risk category
  for (let category in riskCategories) {
    const percentage = ((riskCategories[category] / totalEmployees) * 100).toFixed(2);
    riskCategories[category] = {
      count: riskCategories[category],
      percentage: percentage
    };
  }

  return {
    sectionAverages,       // Average scores per section
    riskCategories,        // Risk categories with percentages
    totalEmployees         // Total number of employees
  };
};
  

const calculateAgeDistribution = (employees) => {
  const ageDistribution = {
    "<25": 0,
    "25-34": 0,
    "35-44": 0,
    "45-54": 0,
    "55+": 0,
  };

  employees.forEach((emp) => {
    const age = new Date().getFullYear() - new Date(JSON.parse(emp.employee_info).dob).getFullYear();
    if (age < 25) ageDistribution["<25"]++;
    else if (age < 35) ageDistribution["25-34"]++;
    else if (age < 45) ageDistribution["35-44"]++;
    else if (age < 55) ageDistribution["45-54"]++;
    else ageDistribution["55+"]++;
  });

  return ageDistribution;
};


// const calculateBloodPressureData = (employees) => {
//   const bpData = {
//     normal: 0,
//     elevated: 0,
//     hypertensionStage1: 0,
//     hypertensionStage2: 0,
//     total: 0,
//   };

//   const bloodPressureThresholds = [
//     { range: "Normal", sys: [0, 119], dia: [0, 79] },
//     { range: "Elevated", sys: [120, 129], dia: [80, 84] },
//     { range: "Hypertension Stage 1", sys: [130, 139], dia: [85, 89] },
//     { range: "Hypertension Stage 2", sys: [140, Infinity], dia: [90, Infinity] },
//   ];

//   employees.forEach((emp) => {
//     let healthAssessment;
//     try {
//       healthAssessment = JSON.parse(emp.health_assessment);
//       console.log("Health Assessment: ", healthAssessment);  // Check the parsed data
//     } catch (error) {
//       console.log("Error parsing health_assessment for employee", emp.id);
//       return;
//     }

//     const bpResponse = healthAssessment?.questions?.find(q => q.questionId === 'PMH14')?.response;
//     console.log("BP Response: ", bpResponse);  // Log the BP response

//     if (bpResponse) {
//       const [sysRange, diaRange] = bpResponse.split("/").map(val => val.trim().replace('mm Hg', '').replace('mmHg', ''));
//       const [sysMin] = sysRange.split("-").map(val => parseInt(val.trim()));
//       const [diaMin] = diaRange.split("-").map(val => parseInt(val.trim()));

//       console.log("Systolic Min: ", sysMin, "Diastolic Min: ", diaMin);  // Log parsed BP values

//       bloodPressureThresholds.forEach((threshold) => {
//         if (sysMin >= threshold.sys[0] && sysMin <= threshold.sys[1] && diaMin >= threshold.dia[0] && diaMin <= threshold.dia[1]) {
//           console.log("Matched BP category: ", threshold.range);  // Check if the condition is met
//           bpData[threshold.range.toLowerCase().replace(/\s/g, '')]++;
//         }
//       });
//     }
//   });

//   if (bpData.total === 0) {
//     console.log("No valid BP data processed.");
//     return {
//       normal: { count: 0, percentage: '0.00' },
//       elevated: { count: 0, percentage: '0.00' },
//       hypertensionStage1: { count: 0, percentage: '0.00' },
//       hypertensionStage2: { count: 0, percentage: '0.00' },
//     };
//   }

//   return {
//     normal: { count: bpData.normal, percentage: ((bpData.normal / bpData.total) * 100).toFixed(2) },
//     elevated: { count: bpData.elevated, percentage: ((bpData.elevated / bpData.total) * 100).toFixed(2) },
//     hypertensionStage1: { count: bpData.hypertensionStage1, percentage: ((bpData.hypertensionStage1 / bpData.total) * 100).toFixed(2) },
//     hypertensionStage2: { count: bpData.hypertensionStage2, percentage: ((bpData.hypertensionStage2 / bpData.total) * 100).toFixed(2) },
//   };
// };


// const calculateDiabetesData = (employees) => {
//   const diabetesData = {
//     normal: 0,
//     prediabetes: 0,
//     diabetes: 0,
//     highRisk: 0,
//     total: 0,
//   };

//   employees.forEach((emp) => {
//     let healthAssessment;
//     try {
//       healthAssessment = JSON.parse(emp.health_assessment);
//       console.log("Health Assessment: ", healthAssessment);
//     } catch (error) {
//       console.log("Error parsing health_assessment for employee", emp.id);
//       return;
//     }

//     const glucoseResponse = healthAssessment?.questions?.find(q => q.questionId === 'PMH15')?.response;
//     console.log("Glucose Response: ", glucoseResponse);  // Log the glucose response

//     if (glucoseResponse) {
//       const glucoseLevel = parseFloat(glucoseResponse.split("-")[0].replace(/[^\d.-]/g, ''));
//       console.log("Glucose Level: ", glucoseLevel);  // Log parsed glucose level

//       if (glucoseLevel >= 150) {
//         diabetesData.highRisk++;
//       } else if (glucoseLevel >= 126) {
//         diabetesData.diabetes++;
//       } else if (glucoseLevel >= 100) {
//         diabetesData.prediabetes++;
//       } else {
//         diabetesData.normal++;
//       }
//     }
//   });

//   if (diabetesData.total === 0) {
//     console.log("No valid glucose data processed.");
//     return {
//       normal: { count: 0, percentage: '0.00' },
//       prediabetes: { count: 0, percentage: '0.00' },
//       diabetes: { count: 0, percentage: '0.00' },
//       highRisk: { count: 0, percentage: '0.00' },
//     };
//   }

//   return {
//     normal: { count: diabetesData.normal, percentage: ((diabetesData.normal / diabetesData.total) * 100).toFixed(2) },
//     prediabetes: { count: diabetesData.prediabetes, percentage: ((diabetesData.prediabetes / diabetesData.total) * 100).toFixed(2) },
//     diabetes: { count: diabetesData.diabetes, percentage: ((diabetesData.diabetes / diabetesData.total) * 100).toFixed(2) },
//     highRisk: { count: diabetesData.highRisk, percentage: ((diabetesData.highRisk / diabetesData.total) * 100).toFixed(2) },
//   };
// };



// const calculateCholesterolData = (employees) => {
//   const cholesterolData = {
//     optimal: 0,
//     good: 0,
//     borderline: 0,
//     moderate: 0,
//     highRisk: 0,
//     total: 0,
//   };

//   const cholesterolThresholds = [
//     { range: "Optimal", ratio: [0, 1.5] },
//     { range: "Good", ratio: [1.5, 2.0] },
//     { range: "Borderline", ratio: [2.0, 2.5] },
//     { range: "Moderate", ratio: [2.5, 3.0] },
//     { range: "High Risk", ratio: [3.0, Infinity] },
//   ];

//   employees.forEach((emp) => {
//     let healthAssessment;

//     try {
//       healthAssessment = JSON.parse(emp.health_assessment);
//     } catch (error) {
//       console.log("Error parsing health_assessment for employee", emp.id);
//       return;
//     }

//     cholesterolData.total++;

//     const cholesterolResponse = healthAssessment?.questions?.find(q => q.questionId === 'PMH16')?.response;

//     if (cholesterolResponse) {
//       const [ldl, hdl] = cholesterolResponse.split("/").map(val => parseFloat(val.trim()));

//       if (!isNaN(ldl) && !isNaN(hdl)) {
//         const ratio = ldl / hdl;

//         cholesterolThresholds.forEach((threshold) => {
//           if (ratio >= threshold.ratio[0] && ratio < threshold.ratio[1]) {
//             cholesterolData[threshold.range.toLowerCase().replace(/\s/g, '')]++;
//           }
//         });
//       }
//     }
//   });

//   if (cholesterolData.total === 0) {
//     return {
//       optimal: { count: 0, percentage: '0.00' },
//       good: { count: 0, percentage: '0.00' },
//       borderline: { count: 0, percentage: '0.00' },
//       moderate: { count: 0, percentage: '0.00' },
//       highRisk: { count: 0, percentage: '0.00' },
//     };
//   }

//   return {
//     optimal: { count: cholesterolData.optimal, percentage: ((cholesterolData.optimal / cholesterolData.total) * 100).toFixed(2) },
//     good: { count: cholesterolData.good, percentage: ((cholesterolData.good / cholesterolData.total) * 100).toFixed(2) },
//     borderline: { count: cholesterolData.borderline, percentage: ((cholesterolData.borderline / cholesterolData.total) * 100).toFixed(2) },
//     moderate: { count: cholesterolData.moderate, percentage: ((cholesterolData.moderate / cholesterolData.total) * 100).toFixed(2) },
//     highRisk: { count: cholesterolData.highRisk, percentage: ((cholesterolData.highRisk / cholesterolData.total) * 100).toFixed(2) },
//   };
// };


const calculateExpensesChart = (employees) => {
  const expensesData = {
    opd: 0,
    Ipd: 0,
    lab: 0,
    pharmacy: 0,
    total: 0
  };

  const totalEmployees = employees.length;

  if (totalEmployees === 0) {
    return {
      opd: '0.00',
      Ipd: '0.00',
      lab: '0.00',
      pharmacy: '0.00',
      total: '100.00'
    };
  }

  const expenseOptions = {
    "HBE4": {
      "More than PKR 6000": 5,
      "PKR 5000 - PKR 6000": 4,
      "PKR 3000 - PKR 4000": 3,
      "PKR 1000 - PKR 2000": 2,
      "Less than PKR 1000": 1
    },
    "HBE5": {
      "More than PKR 10,000": 5,
      "PKR 6000 - PKR 10,000": 4,
      "PKR 4000 - PKR 5000": 3,
      "PKR 2000 - PKR 3000": 2,
      "Less than PKR 2000": 1
    },
    "HBE6": {
      "More than PKR 15,000": 5,
      "PKR 12,000 - PKR 15,000": 4,
      "PKR 8000 - PKR 11,000": 3,
      "PKR 5000 - PKR 8000": 2,
      "Less than PKR 5000": 1
    },
    "HBE2": {
      "OPD": 1,
      "IPD": 1,
      "Pharmacy": 1,
      "Lab and Diagnostics": 1,
      "Homecare services": 1,
      "Telemedicine": 1
    },
    "HBE3": {
      "OPD": 1,
      "IPD": 1,
      "Pharmacy": 1,
      "Lab and Diagnostics": 1,
      "Homecare": 1,
      "Maternity": 1,
      "Telemedicine": 1,
      "Dental procedure": 1,
      "Pre-existing condition": 1,
      "Wellness program and preventive care": 1
    }
  };

  employees.forEach((emp) => {
    let healthAssessment;
    try {
      healthAssessment = JSON.parse(emp.health_assessment);
    } catch (error) {
      return;
    }

    healthAssessment.forEach((section) => {
      if (section.subHeading === "Health Benefits and Expenditure") {
        section.questions.forEach((question) => {
          if (question.questionId === "HBE4" || question.questionId === "HBE5" || question.questionId === "HBE6") {
            const expenseType = question.questionId;
            const expenseValue = expenseOptions[expenseType] && expenseOptions[expenseType][question.response];
            if (expenseValue) {
              if (expenseType === "HBE4") {
                expensesData.opd += expenseValue;
              } else if (expenseType === "HBE5") {
                expensesData.lab += expenseValue;
              } else if (expenseType === "HBE6") {
                expensesData.pharmacy += expenseValue;
              }
            }
          }

          if (question.questionId === "HBE2") {
            const servicesUsed = Array.isArray(question.response) ? question.response : [question.response];
            servicesUsed.forEach((service) => {
              if (expenseOptions.HBE2[service]) {
                expensesData[service] = (expensesData[service] || 0) + expenseOptions.HBE2[service];
              }
            });
          }

          if (question.questionId === "HBE3") {
            const servicesCovered = Array.isArray(question.response) ? question.response : [question.response];
            servicesCovered.forEach((service) => {
              if (expenseOptions.HBE3[service]) {
                expensesData[service] = (expensesData[service] || 0) + expenseOptions.HBE3[service];
              }
            });
          }
        });
      }
    });
  });

  expensesData.total = expensesData.opd + expensesData.IPD + expensesData.lab + expensesData.pharmacy;

  if (expensesData.total === 0) {
    return {
      opd: '0.00',
      IPD: '0.00',
      lab: '0.00',
      pharmacy: '0.00',
      total: '100.00'
    };
  }

  const totalSum = expensesData.total;
  return {
    opd: ((expensesData.opd / totalSum) * 100).toFixed(2),
    IPD: ((expensesData.IPD / totalSum) * 100).toFixed(2),
    lab: ((expensesData.lab / totalSum) * 100).toFixed(2),
    pharmacy: ((expensesData.pharmacy / totalSum) * 100).toFixed(2),
    total: '100.00'
  };
};



// const calculateHealthData = (employees, questionData) => {
//   // Categories for each health metric (same as before)
//   const bloodPressureCategories = [
//     { answer: "140 mmHg or higher / 90 mmHg or higher", category: "hypertensionStage2" },
//     { answer: "130-139 mm Hg / 85-89 mmHg", category: "hypertensionStage1" },
//     { answer: "120-129 mmHg / 80-84 mmHg", category: "elevated" },
//     { answer: "80-119 mmHg / 60-79 mmHg", category: "normal" },
//     { answer: "Less than 80 mmHg / less than 60 mmHg", category: "normal" },
//     { answer: "I don't know", category: "normal" }
//   ];

//   const diabetesCategories = [
//     { answer: "150 mg/dL or higher", category: "highRisk" },
//     { answer: "126-149 mg/dL", category: "diabetes" },
//     { answer: "100-125 mg/dL", category: "prediabetes" },
//     { answer: "70-99 mg/dL", category: "normal" },
//     { answer: "Less than 70 mg/dL", category: "normal" },
//     { answer: "I don't know", category: "normal" }
//   ];

//   const cholesterolCategories = [
//     { answer: "Greater than 3", category: "highRisk" },
//     { answer: "2.5-3", category: "moderate" },
//     { answer: "2-2.5", category: "borderline" },
//     { answer: "1.5-2", category: "good" },
//     { answer: "Less than 1.5", category: "optimal" },
//     { answer: "I don't know", category: "normal" }
//   ];

//   // Initialize counts for each health category
//   let bloodPressureData = {
//     normal: { count: 0, percentage: "0.00" },
//     elevated: { count: 0, percentage: "0.00" },
//     hypertensionStage1: { count: 0, percentage: "0.00" },
//     hypertensionStage2: { count: 0, percentage: "0.00" }
//   };

//   let diabetesData = {
//     normal: { count: 0, percentage: "0.00" },
//     prediabetes: { count: 0, percentage: "0.00" },
//     diabetes: { count: 0, percentage: "0.00" },
//     highRisk: { count: 0, percentage: "0.00" }
//   };

//   let cholesterolData = {
//     optimal: { count: 0, percentage: "0.00" },
//     good: { count: 0, percentage: "0.00" },
//     borderline: { count: 0, percentage: "0.00" },
//     moderate: { count: 0, percentage: "0.00" },
//     highRisk: { count: 0, percentage: "0.00" }
//   };

//   const totalEmployees = employees.length;

//   // Debugging: Check the employees' responses
//   console.log("Total Employees:", totalEmployees);
//   employees.forEach(emp => {
//     const healthAssessment = JSON.parse(emp.health_assessment);  // Assuming this is how the health assessment data is stored
//     const questions = healthAssessment?.questions;

//     if (!questions) {
//       console.log("No questions data for employee:", emp); // Debugging missing questions
//       return; // If no questions, skip the current employee
//     }

//     console.log("Employee Responses:", questions); // Debugging employee responses

//     // Process blood pressure response
//     const bloodPressureResponse = questions.find(q => q.questionId === "PMH14")?.response;
//     console.log("Blood Pressure Response:", bloodPressureResponse); // Debugging Blood Pressure
//     if (bloodPressureResponse) {
//       const bloodPressureCategory = bloodPressureCategories.find(o => 
//         o.answer.toLowerCase().trim() === bloodPressureResponse.toLowerCase().trim())?.category;

//       console.log("Matched Blood Pressure Category:", bloodPressureCategory); // Debugging matched category

//       if (bloodPressureCategory) {
//         bloodPressureData[bloodPressureCategory].count += 1;
//       } else {
//         console.log(`Unmatched Blood Pressure Response: ${bloodPressureResponse}`);
//       }
//     }

//     // Process diabetes response
//     const diabetesResponse = questions.find(q => q.questionId === "PMH15")?.response;
//     console.log("Diabetes Response:", diabetesResponse); // Debugging Diabetes
//     if (diabetesResponse) {
//       const diabetesCategory = diabetesCategories.find(o => 
//         o.answer.toLowerCase().trim() === diabetesResponse.toLowerCase().trim())?.category;

//       console.log("Matched Diabetes Category:", diabetesCategory); // Debugging matched category

//       if (diabetesCategory) {
//         diabetesData[diabetesCategory].count += 1;
//       } else {
//         console.log(`Unmatched Diabetes Response: ${diabetesResponse}`);
//       }
//     }

//     // Process cholesterol response
//     const cholesterolResponse = questions.find(q => q.questionId === "PMH16")?.response;
//     console.log("Cholesterol Response:", cholesterolResponse); // Debugging Cholesterol
//     if (cholesterolResponse) {
//       const cholesterolCategory = cholesterolCategories.find(o => 
//         o.answer.toLowerCase().trim() === cholesterolResponse.toLowerCase().trim())?.category;

//       console.log("Matched Cholesterol Category:", cholesterolCategory); // Debugging matched category

//       if (cholesterolCategory) {
//         cholesterolData[cholesterolCategory].count += 1;
//       } else {
//         console.log(`Unmatched Cholesterol Response: ${cholesterolResponse}`);
//       }
//     }
//   });

//   // Calculate the percentage for each category
//   const calculatePercentage = (data) => {
//     Object.keys(data).forEach(key => {
//       data[key].percentage = ((data[key].count / totalEmployees) * 100).toFixed(2);
//     });
//   };

//   calculatePercentage(bloodPressureData);
//   calculatePercentage(diabetesData);
//   calculatePercentage(cholesterolData);

//   // Debugging: Log final health data counts and percentages
//   console.log("Final Blood Pressure Data:", bloodPressureData);
//   console.log("Final Diabetes Data:", diabetesData);
//   console.log("Final Cholesterol Data:", cholesterolData);

//   // Return the processed health data
//   return {
//     bloodPressureData,
//     diabetesData,
//     cholesterolData,
//     totalEmployees
//   };
// };
// const getBloodPressureData = (healthAssessment) => {
//   const bpData = healthAssessment?.find(item => item.subHeading === "Personal Medical History")
//     ?.questions?.find(q => q.questionId === "PMH14" && q.response);

//   if (!bpData || !bpData.response) {
//     return { bpValue: null, bpInterpretation: "Unknown" };
//   }

//   const response = bpData.response.trim().toLowerCase();

//   const bpCategories = {
//     "140 mmhg or higher / 90 mmhg or higher": {
//       bpValue: "140+/90+",
//       bpInterpretation: "Hypertension stage 2; high risk for cardiovascular complications; urgent medical intervention may be required."
//     },
//     "130-139 mm hg / 85-89 mmhg": {
//       bpValue: "130-139 / 85-89",
//       bpInterpretation: "Hypertension stage 1; requires lifestyle changes and possibly medication."
//     },
//     "120-129 mmhg / 80-84 mmhg": {
//       bpValue: "120-129 / 80-84",
//       bpInterpretation: "Elevated blood pressure; lifestyle modifications are recommended to prevent hypertension."
//     },
//     "80-119 mmhg / 60-79 mmhg": {
//       bpValue: "Normal",
//       bpInterpretation: "Normal blood pressure; indicates good cardiovascular health."
//     },
//     "less than 80 mmhg / less than 60 mmhg": {
//       bpValue: "Low",
//       bpInterpretation: "Low blood pressure; may require further evaluation if symptoms are present (e.g., dizziness, fainting)."
//     },
//     "i don't know": {
//       bpValue: "Unknown",
//       bpInterpretation: "Blood Pressure Unknown"
//     }
//   };

//   if (bpCategories[response]) {
//     return bpCategories[response];
//   }

//   return { bpValue: null, bpInterpretation: "Unknown" };
// };

// const getDiabetesRisk = (healthAssessment) => {
//   const glucoseData = healthAssessment?.find(item => item.subHeading === "Personal Medical History")
//     ?.questions?.find(q => q.questionId === "PMH15" && q.response);

//   if (!glucoseData || !glucoseData.response) return { glucose_level: null, diabetesRisk: "Unknown" };

//   let glucose_level;

//   if (typeof glucoseData.response === 'string') {
//     glucose_level = parseFloat(glucoseData.response.replace(/[^\d.-]/g, ''));
//   } else if (typeof glucoseData.response === 'number') {
//     glucose_level = glucoseData.response;
//   } else {
//     glucose_level = null;
//   }

//   if (glucose_level === null || isNaN(glucose_level)) {
//     return { glucose_level: null, diabetesRisk: "Unknown" };
//   }

//   let diabetesRisk = "Normal";
//   if (glucose_level >= 150) {
//     diabetesRisk = "Indicates uncontrolled diabetes; urgent medical attention needed.";
//   } else if (glucose_level >= 126) {
//     diabetesRisk = "Indicates diabetes; further testing and management are required.";
//   } else if (glucose_level >= 100) {
//     diabetesRisk = "Indicates prediabetes; lifestyle modifications are recommended.";
//   } else if (glucose_level >= 70) {
//     diabetesRisk = "Indicates normal fasting glucose; generally considered healthy.";
//   }

//   return { glucose_level, diabetesRisk };
// };

// const getCholesterolRisk = (healthAssessment) => {
//   const cholesterolData = healthAssessment?.find(item => item.subHeading === "Personal Medical History")
//     ?.questions?.find(q => q.questionId === "PMH16" && q.response);

//   if (!cholesterolData || !cholesterolData.response) return { cholesterol_level: null, cholesterolRisk: "Unknown" };

//   const response = cholesterolData.response.trim().toLowerCase();

//   if (response === "greater than 3") {
//     return { cholesterol_level: 3.1, cholesterolRisk: "High risk; indicates a significant risk for cardiovascular disease; medical intervention may be necessary." };
//   }
//   if (response === "2.5-3") {
//     return { cholesterol_level: (2.5 + 3) / 2, cholesterolRisk: "Moderate risk; individuals should consider making lifestyle changes." };
//   }
//   if (response === "2-2.5") {
//     return { cholesterol_level: (2 + 2.5) / 2, cholesterolRisk: "Borderline; may require monitoring and lifestyle modifications." };
//   }
//   if (response === "1.5-2") {
//     return { cholesterol_level: (1.5 + 2) / 2, cholesterolRisk: "Good ratio; generally considered healthy, with a low risk of CVD." };
//   }
//   if (response === "less than 1.5") {
//     return { cholesterol_level: 1.4, cholesterolRisk: "Optimal ratio; indicates low risk for cardiovascular disease." };
//   }
//   if (response === "i don't know") {
//     return { cholesterol_level: null, cholesterolRisk: "Unknown" };
//   }

//   return { cholesterol_level: null, cholesterolRisk: "Unknown" };
// };

// const calculateFitnessHealthData = (companySlug, allEmployeesData) => {
//   if (!Array.isArray(allEmployeesData)) {
//     console.error("Error: allEmployeesData is not iterable or is undefined.");
//     return []; // Return an empty array if it's not an iterable array.
//   }

//   const companyEmployees = [];
  
//   for (const employee of allEmployeesData) {
//     if (employee.company_slug === companySlug) {
//       const { healthAssessment } = employee;
    
//       const bpData = getBloodPressureData(healthAssessment);
//       const glucoseData = getDiabetesRisk(healthAssessment);
//       const cholesterolData = getCholesterolRisk(healthAssessment);
    
//       companyEmployees.push({
//         employeeId: employee.id,
//         name: employee.name,
//         bloodPressure: bpData,
//         glucoseLevel: glucoseData,
//         cholesterol: cholesterolData,
//         guidelines: {
//           diabetesRisk: glucoseData.diabetesRisk,
//           bloodPressureGuideline: bpData.bpInterpretation,
//           cholesterolGuideline: cholesterolData.cholesterolRisk
//         }
//       });
//     }
//   }

//   return companyEmployees;
// };


// const calculateWomanHealthChart = (employees) => {
//   const gynecologicalOptions = [
//     { answer: "Never", score: 5 },
//     { answer: "Only when needed", score: 4 },
//     { answer: "Once in 3 years", score: 3 },
//     { answer: "Once a year", score: 2 },
//     { answer: "Twice a year", score: 1 }
//   ];

//   const prevalentGynecOptions = [
//     { answer: "Polycystic Ovarian Syndrome (PCOS)", score: 3 },
//     { answer: "Endometriosis", score: 3 },
//     { answer: "Uterine Fibroids", score: 3 },
//     { answer: "Ovarian cysts", score: 3 },
//     { answer: "Menstrual Irregularities", score: 3 },
//     { answer: "None", score: 0 }
//   ];

//   const planningOptions = [
//     { answer: "Yes", score: 3 },
//     { answer: "No", score: 1 }
//   ];

//   const womanHealthData = {
//     gynecological: { options: gynecologicalOptions, total: 0 },
//     prevalentGynec: { options: prevalentGynecOptions, total: 0 },
//     planningToGetPregnant: { options: planningOptions, total: 0 },
//     totalFemales: 0,
//   };

//   const countResponses = (responses, options) => {
//     return options.reduce((acc, option) => {
//       acc[option.answer] = responses.filter(response => response === option.answer).length;
//       return acc;
//     }, {});
//   };

//   employees.forEach(emp => {
//     let healthAssessment;
//     let employeeInfo;

//     try {
//       healthAssessment = JSON.parse(emp.health_assessment);
//       employeeInfo = JSON.parse(emp.employee_info);
//     } catch (error) {
//       return;
//     }

//     if (employeeInfo.gender && employeeInfo.gender.toLowerCase() === 'female') {
//       womanHealthData.totalFemales++;

//       const gynecologicalFrequency = healthAssessment?.questions?.find(q => q.questionId === 'WH1')?.response;
//       if (gynecologicalFrequency) {
//         const gynecologicalCounts = countResponses([gynecologicalFrequency], gynecologicalOptions);
//         gynecologicalOptions.forEach(option => {
//           womanHealthData.gynecological[option.answer] = gynecologicalCounts[option.answer];
//         });
//         womanHealthData.gynecological.total++;
//       }

//       const gynecologicalConditions = healthAssessment?.questions?.find(q => q.questionId === 'WH2')?.response;
//       if (gynecologicalConditions && Array.isArray(gynecologicalConditions)) {
//         const conditionCounts = countResponses(gynecologicalConditions, prevalentGynecOptions);
//         prevalentGynecOptions.forEach(option => {
//           womanHealthData.prevalentGynec[option.answer] = conditionCounts[option.answer];
//         });
//         womanHealthData.prevalentGynec.total++;
//       }

//       const planningResponse = healthAssessment?.questions?.find(q => q.questionId === 'WH4')?.response;
//       if (planningResponse) {
//         const planningCounts = countResponses([planningResponse], planningOptions);
//         planningOptions.forEach(option => {
//           womanHealthData.planningToGetPregnant[option.answer] = planningCounts[option.answer];
//         });
//         womanHealthData.planningToGetPregnant.total++;
//       }
//     }
//   });

//   const calculateCategoryPercentages = (categoryData) => {
//     return categoryData.options.map(option => {
//       const count = categoryData[option.answer];
//       const percentage = calculatePercentage(count, categoryData.total);
//       return { answer: option.answer, count, percentage };
//     });
//   };

//   return {
//     gynecological: {
//       options: calculateCategoryPercentages(womanHealthData.gynecological),
//       total: womanHealthData.gynecological.total,
//     },
//     prevalentGynec: {
//       options: calculateCategoryPercentages(womanHealthData.prevalentGynec),
//       total: womanHealthData.prevalentGynec.total,
//     },
//     planningToGetPregnant: {
//       options: calculateCategoryPercentages(womanHealthData.planningToGetPregnant),
//       total: womanHealthData.planningToGetPregnant.total,
//     },
//   };
// };
const calculateWomanHealthChart = (employees) => {
  // Define options for different questions (with exact matches)
  const gynecologicalOptions = [
    { answer: "Never", score: 5 },
    { answer: "Only when needed", score: 4 },
    { answer: "Once in 3 years", score: 3 },
    { answer: "Once a year", score: 2 },
    { answer: "Twice a year", score: 1 }
  ];

  const prevalentGynecOptions = [
    { answer: "Polycystic Ovarian Syndrome (PCOS)", score: 3 },
    { answer: "Endometriosis", score: 3 },
    { answer: "Uterine Fibroids", score: 3 },
    { answer: "Ovarian cysts", score: 3 },
    { answer: "Menstrual Irregularities", score: 3 },
    { answer: "None", score: 0 }
  ];

  const planningOptions = [
    { answer: "Yes", score: 3 },
    { answer: "No", score: 1 }
  ];

  // Initialize the data structure for storing the counts
  const womanHealthData = {
    gynecological: { "Never": 0, "Only when needed": 0, "Once in 3 years": 0, "Once a year": 0, "Twice a year": 0, total: 0 },
    prevalentGynec: { "Polycystic Ovarian Syndrome (PCOS)": 0, "Endometriosis": 0, "Uterine Fibroids": 0, "Ovarian cysts": 0, "Menstrual Irregularities": 0, "None": 0, total: 0 },
    planningToGetPregnant: { "Yes": 0, "No": 0, total: 0 },
    totalFemales: 0,
  };

  // Helper function to count responses based on exact matches
  const countExactResponses = (responses, options) => {
    return options.reduce((acc, option) => {
      acc[option.answer] = responses.filter(response => response === option.answer).length;
      return acc;
    }, {});
  };

  // Iterate through the employees' data
  employees.forEach(emp => {
    let healthAssessment;
    let employeeInfo;

    // Parse the health assessment and employee info
    try {
      healthAssessment = JSON.parse(emp.health_assessment);
      employeeInfo = JSON.parse(emp.employee_info);
    } catch (error) {
      return;
    }

    // Process only female employees
    if (employeeInfo.gender && employeeInfo.gender.toLowerCase() === 'Female') {
      womanHealthData.totalFemales++;

      // Process responses to gynecological frequency question (WH1)
      const gynecologicalFrequency = healthAssessment?.questions?.find(q => q.questionId === 'WH1')?.response;
      if (gynecologicalFrequency) {
        const gynecologicalCounts = countExactResponses([gynecologicalFrequency], gynecologicalOptions);
        gynecologicalOptions.forEach(option => {
          womanHealthData.gynecological[option.answer] += gynecologicalCounts[option.answer] || 0;
        });
        womanHealthData.gynecological.total++;
      }

      // Process responses to prevalent gynecological conditions (WH2)
      const gynecologicalConditions = healthAssessment?.questions?.find(q => q.questionId === 'WH2')?.response;
      if (gynecologicalConditions && Array.isArray(gynecologicalConditions)) {
        const conditionCounts = countExactResponses(gynecologicalConditions.flat(), prevalentGynecOptions);
        prevalentGynecOptions.forEach(option => {
          womanHealthData.prevalentGynec[option.answer] += conditionCounts[option.answer] || 0;
        });
        womanHealthData.prevalentGynec.total++;
      }

      // Process responses to planning to get pregnant question (WH4)
      const planningResponse = healthAssessment?.questions?.find(q => q.questionId === 'WH4')?.response;
      if (planningResponse) {
        const planningCounts = countExactResponses([planningResponse], planningOptions);
        planningOptions.forEach(option => {
          womanHealthData.planningToGetPregnant[option.answer] += planningCounts[option.answer] || 0;
        });
        womanHealthData.planningToGetPregnant.total++;
      }
    }
  });

  // Function to calculate percentages based on total female employees
  const calculatePercentages = (categoryData) => {
    return Object.keys(categoryData).map(option => {
      if (option === "total") return null;  // Skip 'total' key
      const count = categoryData[option];
      const percentage = categoryData.total > 0 ? (count / categoryData.total) * 100 : 0;
      return { answer: option, count, percentage };
    }).filter(item => item !== null);  // Filter out null values
  };

  // Return the final data with counts and percentages
  return {
    gynecological: {
      options: calculatePercentages(womanHealthData.gynecological),
      total: womanHealthData.gynecological.total,
    },
    prevalentGynec: {
      options: calculatePercentages(womanHealthData.prevalentGynec),
      total: womanHealthData.prevalentGynec.total,
    },
    planningToGetPregnant: {
      options: calculatePercentages(womanHealthData.planningToGetPregnant),
      total: womanHealthData.planningToGetPregnant.total,
    },
  };
};

const calculateServicesBenefit = (employees) => {
  const servicesData = {
    Telemedicine: { using: 0, covered: 0 },
    OPD: { using: 0, covered: 0 },
    IPD: { using: 0, covered: 0 },
    Pharmacy: { using: 0, covered: 0 },
    "Lab and Diagnostics": { using: 0, covered: 0 },
    Homecare: { using: 0, covered: 0 },
    Maternity: { using: 0, covered: 0 },
    "Dental procedure": { using: 0, covered: 0 },
    "Pre-existing condition": { using: 0, covered: 0 },
    "Wellness program and preventive care": { using: 0, covered: 0 }
  };

  const totalEmployees = employees.length;

  if (totalEmployees === 0) {
    return { ServiceBenefit: servicesData };
  }

  employees.forEach((emp) => {
    let healthAssessment;
    try {
      healthAssessment = JSON.parse(emp.health_assessment);
    } catch (error) {
      console.error('Error parsing health_assessment for employee:', emp);
      return;
    }

    if (healthAssessment) {
      healthAssessment.forEach((section) => {
        if (section.subHeading === "Health Benefits and Expenditure") {
          section.questions.forEach((question) => {
            if (question.questionId === "HBE2") {
              const servicesUsed = Array.isArray(question.response) ? question.response : [question.response];
              servicesUsed.forEach((service) => {
                if (servicesData[service]) {
                  servicesData[service].using++;
                }
              });
            }

            if (question.questionId === "HBE3") {
              const servicesCovered = Array.isArray(question.response) ? question.response : [question.response];
              servicesCovered.forEach((service) => {
                if (servicesData[service]) {
                  servicesData[service].covered++;
                }
              });
            }
          });
        }
      });
    }
  });

  Object.keys(servicesData).forEach((service) => {
    servicesData[service].using = ((servicesData[service].using / totalEmployees) * 100).toFixed(2);
    servicesData[service].covered = ((servicesData[service].covered / totalEmployees) * 100).toFixed(2);

    if (parseFloat(servicesData[service].using) > 100) {
      servicesData[service].using = "100.00";
    }
    if (parseFloat(servicesData[service].covered) > 100) {
      servicesData[service].covered = "100.00";
    }
  });

  return { ServiceBenefit: servicesData };
};


// question =>question.questionId
  
// const calculateSatisfactionLevels = (employees) => {
//   const satisfactionLevelsByCompany = {};

//   employees.forEach((emp) => {
//     if (emp.satisfaction_info && emp.company_slug) {
//       try {
//         console.log(`Processing employee ${emp.id} from company ${emp.company_slug}`);
//         const satisfactionData = JSON.parse(emp.satisfaction_info);

//         satisfactionData.forEach((question) => {
//           const questionId = question.questionId;
//           const response = question.response;

//           console.log(`Question ID: ${questionId}, Response: ${response}`);

//           if (questionId === "HBE1") {
//             if (!satisfactionLevelsByCompany[emp.company_slug]) {
//               satisfactionLevelsByCompany[emp.company_slug] = { yes: 0, no: 0 };
//             }

//             if (response === "YES") {
//               satisfactionLevelsByCompany[emp.company_slug].yes++;
//             } else if (response === "NO") {
//               satisfactionLevelsByCompany[emp.company_slug].no++;
//             }
//           }
//         });
//       } catch (error) {
//         console.error("Error parsing satisfaction_info for employee:", emp.id);
//       }
//     } else {
//       console.log(`Missing satisfaction_info or company_slug for employee ${emp.id}`);
//     }
//   });

//   console.log("Final satisfaction levels by company:", satisfactionLevelsByCompany);
//   return satisfactionLevelsByCompany;
// };
const calculateSatisfactionLevels = (employees, healthAssessments) => {
  const satisfactionLevelsByCompany = {};

 
  employees.forEach((emp) => {
    const companySlug = emp.company_slug;  
    const assessmentId = emp.assessment_ID; 

    if (companySlug && assessmentId) {
    
      const healthAssessment = healthAssessments.find(ha => ha.assessment_ID === assessmentId);

      if (healthAssessment) {
      
        try {
          const healthAssessmentData = JSON.parse(healthAssessment.health_assessment);  

          healthAssessmentData.forEach((section) => {
            section.questions.forEach((question) => {
              
              if (question.questionId === "HBE1") {
                const response = question.response; 
                
                if (!satisfactionLevelsByCompany[companySlug]) {
                  satisfactionLevelsByCompany[companySlug] = { yes: 0, no: 0 };
                }

               
                if (response === "Yes") {
                  satisfactionLevelsByCompany[companySlug].yes++;
                } else if (response === "No") {
                  satisfactionLevelsByCompany[companySlug].no++;
                }
              }
            });
          });
        } catch (error) {
          console.error(`Error parsing health assessment for employee ${emp.assessment_ID}:`, error);
        }
      }
    }
  });

 
  console.log("Final satisfaction levels by company:", satisfactionLevelsByCompany);
  return satisfactionLevelsByCompany;
};


// const calculateScoringInterpretation = (employees) => {
//     const scoreCategories = {
//       "Severe Risk": { min: 321, max: 400, count: 0 },
//       "Very High Risk": { min: 241, max: 320, count: 0 },
//       "High Risk": { min: 161, max: 240, count: 0 },
//       "Moderate Risk": { min: 81, max: 160, count: 0 },
//       "Low Risk": { min: 0, max: 80, count: 0 },
//     };
  
//     const totalEmployees = employees.length;
  
//     employees.forEach((emp) => {
//       let healthAssessment;
//       try {
//         // Safely parse the health_assessment field
//         healthAssessment = JSON.parse(emp.health_assessment);
//       } catch (error) {
//         // Log the error and skip this employee if parsing fails
//         console.error('Error parsing health_assessment for employee:', emp, error);
//         return; // Skip to the next employee
//       }
  
//       const score = healthAssessment.totalScore || 0; // Assuming totalScore is the key
  
//       // Categorize each employee's score
//       for (let category in scoreCategories) {
//         if (score >= scoreCategories[category].min && score <= scoreCategories[category].max) {
//           scoreCategories[category].count++;
//           break; // Exit once the score is placed in a category
//         }
//       }
//     });
  
//     // Calculate percentage for each risk category
//     Object.keys(scoreCategories).forEach((category) => {
//       scoreCategories[category].percentage = ((scoreCategories[category].count / totalEmployees) * 100).toFixed(2);
//     });
  
//     return scoreCategories;
//   };
  
  


// const getReportData = async (slug) => {
//   try {
//     const [companyResult] = await db.query("SELECT * FROM companies WHERE url = ?", [slug]);
//     if (companyResult.length === 0) throw new Error("Company not found");
//     const company = companyResult[0];

//     const [employeeResult] = await db.query("SELECT * FROM assessment_response WHERE company_slug = ?", [slug]);
//     if (employeeResult.length === 0) throw new Error("No employees found for the company");

//     const totalEmployees = employeeResult.length;
//     const MaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).gender === "Male").length;
//     const FemaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).gender === "Female").length;

//     const ageDistribution = calculateAgeDistribution(employeeResult);
//     const bmiData = calculateBMI(employeeResult);
//     const prevalentHealthCondition = calculateConditionPrevalence(employeeResult);
//     const riskLevels = calculateRiskDistribution(employeeResult);
//     const HealthData = calculateFitnessHealthData(employeeResult);
//     const WomanHealthChart = calculateWomanHealthChart(employeeResult);
//     const satisfactionLevels = calculateSatisfactionLevels(employeeResult);
//     const ServiceBenifit = calculateServicesBenefit(employeeResult);
//     const ExpensesChart = calculateExpensesChart(employeeResult);
//     const SectionWiseRiskDistribution = calculateRiskDistribution(employeeResult);

//     return {
//       company: {
//         id: company.id,
//         name: company.name,
//         companyType: company.companyType,
//         phoneNumber: company.phoneNumber,
//         email: company.email,
//         city: company.city,
//         url: company.url,
//         totalEmployees,
//         MaleEmployees,
//         FemaleEmployees,
//         conditionPrevalence: prevalentHealthCondition,
//         ageDistribution,
//         bmiData,
//         HealthData,
//         WomanHealthChart,
//         ExpensesChart,
//         satisfactionLevels,
//         SectionWiseRiskDistribution,
//         ServiceBenifit,
//         riskLevels,
//       },
//     };
//   } catch (error) {
//     logger.error("Error fetching report data:", error);
//     throw new Error("Error fetching report data");
//   }
// };
const getReportData = async (slug) => {
  try {
    // Fetch company data based on the provided slug
    const [companyResult] = await db.query("SELECT * FROM companies WHERE url = ?", [slug]);
    if (companyResult.length === 0) throw new Error("Company not found");
    const company = companyResult[0];

    // Fetch employee data (assessment responses) for the specified company
    const [employeeResult] = await db.query("SELECT * FROM assessment_response WHERE company_slug = ?", [slug]);
    if (employeeResult.length === 0) throw new Error("No employees found for the company");

    // Get total employees and gender distribution
    const totalEmployees = employeeResult.length;
    const MaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).gender === "Male").length;
    const FemaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).gender === "Female").length;

    // Calculate health-related data
    const ageDistribution = calculateAgeDistribution(employeeResult);
    const bmiData = calculateBMI(employeeResult);
    const prevalentHealthCondition = calculateConditionPrevalence(employeeResult);
    const riskLevels = calculateRiskDistribution(employeeResult);
    const HealthData = calculateFitnessHealthData(employeeResult); // This includes BP, cholesterol, and glucose levels
    const WomanHealthChart = calculateWomanHealthChart(employeeResult);
    const satisfactionLevels = calculateSatisfactionLevels(employeeResult);
    const ServiceBenifit = calculateServicesBenefit(employeeResult);
    const ExpensesChart = calculateExpensesChart(employeeResult);
    const SectionWiseRiskDistribution = calculateRiskDistribution(employeeResult);

    // Return the report data for the company
    return {
      company: {
        id: company.id,
        name: company.name,
        companyType: company.companyType,
        phoneNumber: company.phoneNumber,
        email: company.email,
        city: company.city,
        url: company.url,
        totalEmployees,
        MaleEmployees,
        FemaleEmployees,
        conditionPrevalence: prevalentHealthCondition,
        ageDistribution,
        bmiData,
        HealthData, // Includes BP, diabetes, cholesterol data
        WomanHealthChart,
        ExpensesChart,
        satisfactionLevels,
        SectionWiseRiskDistribution,
        ServiceBenifit,
        riskLevels,
      },
    };
  } catch (error) {
    logger.error("Error fetching report data:", error);
    throw new Error("Error fetching report data");
  }
};

// Helper function to calculate fitness health data (BP, diabetes, cholesterol)
const calculateFitnessHealthData = (allEmployeesData) => {
  if (!Array.isArray(allEmployeesData)) {
    console.error("Error: allEmployeesData is not iterable.");
    return [];
  }

  return allEmployeesData.map((employee) => {
    const { healthAssessment } = employee;
    const bpData = getBloodPressureData(healthAssessment);
    const glucoseData = getDiabetesRisk(healthAssessment);
    const cholesterolData = getCholesterolRisk(healthAssessment);

    return {
      employeeId: employee.id,
      name: employee.name,
      bloodPressure: bpData,
      glucoseLevel: glucoseData,
      cholesterol: cholesterolData,
      guidelines: {
        diabetesRisk: glucoseData.diabetesRisk,
        bloodPressureGuideline: bpData.bpInterpretation,
        cholesterolGuideline: cholesterolData.cholesterolRisk
      }
    };
  });
};

// Blood Pressure Data Extraction
const getBloodPressureData = (healthAssessment) => {
  const bpData = healthAssessment?.find(item => item.subHeading === "Personal Medical History")
    ?.questions?.find(q => q.questionId === "PMH14" && q.response);
  if (!bpData || !bpData.response) {
    return { bpValue: null, bpInterpretation: "Unknown" };
  }

  const response = bpData.response.trim().toLowerCase();
  const bpCategories = {
    "140 mmhg or higher / 90 mmhg or higher": { bpValue: "140+/90+", bpInterpretation: "Hypertension stage 2; high risk for cardiovascular complications." },
    "130-139 mm hg / 85-89 mmhg": { bpValue: "130-139 / 85-89", bpInterpretation: "Hypertension stage 1; requires lifestyle changes." },
    "120-129 mmhg / 80-84 mmhg": { bpValue: "120-129 / 80-84", bpInterpretation: "Elevated blood pressure; lifestyle modifications needed." },
    "80-119 mmhg / 60-79 mmhg": { bpValue: "Normal", bpInterpretation: "Normal blood pressure." },
    "less than 80 mmhg / less than 60 mmhg": { bpValue: "Low", bpInterpretation: "Low blood pressure; may need further evaluation." },
    "i don't know": { bpValue: "Unknown", bpInterpretation: "Blood Pressure Unknown" }
  };

  return bpCategories[response] || { bpValue: null, bpInterpretation: "Unknown" };
};

// Diabetes Risk (Glucose level) Extraction
const getDiabetesRisk = (healthAssessment) => {
  const glucoseData = healthAssessment?.find(item => item.subHeading === "Personal Medical History")
    ?.questions?.find(q => q.questionId === "PMH15" && q.response);
  if (!glucoseData || !glucoseData.response) return { glucose_level: null, diabetesRisk: "Unknown" };

  const glucose_level = parseFloat(glucoseData.response.replace(/[^\d.-]/g, ''));
  if (isNaN(glucose_level)) return { glucose_level: null, diabetesRisk: "Unknown" };

  let diabetesRisk = "Normal";
  if (glucose_level >= 150) {
    diabetesRisk = "Indicates uncontrolled diabetes; urgent medical attention needed.";
  } else if (glucose_level >= 126) {
    diabetesRisk = "Indicates diabetes; further testing and management are required.";
  } else if (glucose_level >= 100) {
    diabetesRisk = "Indicates prediabetes; lifestyle changes are recommended.";
  } else if (glucose_level >= 70) {
    diabetesRisk = "Indicates normal fasting glucose; generally considered healthy.";
  }

  return { glucose_level, diabetesRisk };
};

// Cholesterol Risk Extraction
const getCholesterolRisk = (healthAssessment) => {
  const cholesterolData = healthAssessment?.find(item => item.subHeading === "Personal Medical History")
    ?.questions?.find(q => q.questionId === "PMH16" && q.response);
  if (!cholesterolData || !cholesterolData.response) return { cholesterol_level: null, cholesterolRisk: "Unknown" };

  const response = cholesterolData.response.trim().toLowerCase();
  const cholesterolLevels = {
    "greater than 3": { cholesterol_level: 3.1, cholesterolRisk: "High risk; significant risk for cardiovascular disease." },
    "2.5-3": { cholesterol_level: (2.5 + 3) / 2, cholesterolRisk: "Moderate risk; individuals should consider lifestyle changes." },
    "2-2.5": { cholesterol_level: (2 + 2.5) / 2, cholesterolRisk: "Borderline; may require monitoring." },
    "1.5-2": { cholesterol_level: (1.5 + 2) / 2, cholesterolRisk: "Good ratio; low risk of cardiovascular disease." },
    "less than 1.5": { cholesterol_level: 1.4, cholesterolRisk: "Optimal ratio; low risk for cardiovascular disease." },
    "i don't know": { cholesterol_level: null, cholesterolRisk: "Unknown" }
  };

  return cholesterolLevels[response] || { cholesterol_level: null, cholesterolRisk: "Unknown" };
};

  const generatePdfReport = async (slug, reportData) => {
    try {
      const company = reportData?.company;
      if (!company) {
        throw new Error("Company data is missing from report data");
      }
  
      const riskSummary = company.riskSummary ?? {};
      const bpCategories = company.healthMetrics?.bpCategories ?? {};
      const diabetesCategories = company.healthMetrics?.diabetesCategories ?? {};
      const cholesterolCategories = company.healthMetrics?.cholesterolCategories ?? {};
      const prevalentHealthCondition = company.prevalentHealthCondition ?? {};
      const sectionWiseRiskDistribution = company.sectionWiseRiskDistribution ?? {};
  
      const reportHtml = `
        <html>
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>${company.name} - Report</title>
          </head>
          <body>
            <h1>Health Report for ${company.name}</h1>
            
            <h2>Employee Statistics</h2>
            <p>Total Employees: ${company.totalEmployees ?? 'N/A'}</p>
            <p>Male Employees: ${company.MaleEmployees ?? 'N/A'}</p>
            <p>Female Employees: ${company.FemaleEmployees ?? 'N/A'}</p>
            
            <h2>Condition Prevalence</h2>
            <ul>${Object.entries(company.conditionPrevalence ?? {}).map(([condition, count]) => `<li>${condition}: ${count}</li>`).join("")}</ul>
     
            <h2>BMI Categories</h2>
            <ul>${Object.entries(company.bmiData ?? {}).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>
    
            <h2>Age Distribution</h2>
            <ul>${Object.entries(company.ageDistribution ?? {}).map(([ageRange, count]) => `<li>${ageRange}: ${count}</li>`).join("")}</ul>
    
            <h2>Risk Summary</h2>
            <ul>
              <li>Low Risk: ${riskSummary.low ?? 0}</li>
              <li>Moderate Risk: ${riskSummary.moderate ?? 0}</li>
              <li>High Risk: ${riskSummary.high ?? 0}</li>
            </ul>
    
            <h2>Health Metrics</h2>
            <p>Blood Pressure Categories:</p>
            <ul>${Object.entries(bpCategories).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>
    
            <p>Diabetes Categories:</p>
            <ul>${Object.entries(diabetesCategories).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>
    
            <p>Cholesterol Categories:</p>
            <ul>${Object.entries(cholesterolCategories).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>
    
            <h2>Prevalent Health Conditions</h2>
            <ul>${Object.entries(prevalentHealthCondition).map(([condition, percentage]) => `<li>${condition}: ${percentage}</li>`).join("")}</ul>
    
            <h2>Section-Wise Risk Distribution</h2>
            <ul>${Object.entries(sectionWiseRiskDistribution).map(([section, risks]) => `
                <li>${section}:
                  <ul>
                    ${Object.entries(risks).map(([riskLevel, count]) => `<li>${riskLevel}: ${count}</li>`).join("")}
                  </ul>
                </li>
              `).join("")}</ul>
          </body>
        </html>`;
  
      const browser = await puppeteer.launch();
      const page = await browser.newPage();
      await page.setContent(reportHtml);
      const filePath = path.join(__dirname, "../reports", `${slug}-report.pdf`);
      await page.pdf({ path: filePath });
      await browser.close();
      
      return filePath;
    } catch (error) {
      logger.error("Error generating PDF report:", error);
      throw new Error("Error generating PDF report");
    }
  };
  
module.exports = {
  getReportData,
  generatePdfReport,
};


// const db = require("../config/db");
// const logger = require("../utils/logger");
// const puppeteer = require("puppeteer");
// const path = require("path");

// const healthKeywords = {
//   "Rheumatoid Arthritis": ["arthritis", "joint pain"],
//   Diabetes: ["diabetes", "high blood sugar"],
//   "Hypertension (High BP)": ["hypertension", "high blood pressure"],
//   "High Cholesterol": ["cholesterol"],
//   Gout: ["gout"],
//   Anemia: ["anemia"],
//   Fibromyalgia: ["fibromyalgia"],
//   COPD: ["lung disease", "COPD"],
//   "Metabolic Disorder": ["metabolic disorder"],
//   "Thyroid Disease": ["thyroid"],
//   "Cardiovascular Disease": ["heart disease", "cardiovascular"],
//   Asthma: ["asthma"],
//   Osteoporosis: ["osteoporosis"],
//   "Chronic Kidney Disease": ["kidney disease"],
//   "Urogenital Disease": ["urogenital"],
// };

// const calculateBMI = (employees) => {
//     const bmiData = {
//       "Below-Normal-Weight": 0,
//       "Normal-Weight": 0,
//       "Overweight": 0,
//       "Class-I-Obesity": 0,
//       "Class-II-Obesity": 0,
//       "Class-III-Obesity": 0,
//     };
  
//     employees.forEach((emp) => {
//       const { weight, height } = JSON.parse(emp.employee_info);
//       console.log("Employee Info (BMI):", emp.employee_info); // Log employee data
//       console.log("Weight:", weight, "Height:", height); // Log weight and height
  
//       if (weight && height) {
//         const bmi = weight / Math.pow(height / 100, 2);
//         console.log("Calculated BMI:", bmi); // Log calculated BMI
//         let category = "Below-Normal-Weight";
//         if (bmi >= 18.5 && bmi <= 24.9) category = "Normal-Weight";
//         else if (bmi >= 25 && bmi <= 29.9) category = "Overweight";
//         else if (bmi >= 30 && bmi <= 34.9) category = "Class-I-Obesity";
//         else if (bmi >= 35 && bmi <= 39.9) category = "Class-II-Obesity";
//         else if (bmi >= 40) category = "Class-III-Obesity";
//         bmiData[category]++;
//       }
//     });
  
//     console.log("Final BMI Data:", bmiData); // Log final BMI data
//     return bmiData;
//   };
  
//   const calculateConditionPrevalence = (employees) => {
//     const conditionPrevalence = {};
  
//     employees.forEach((emp) => {
//       const healthAssessment = JSON.parse(emp.health_assessment);
//       console.log("Health Assessment:", healthAssessment); // Log health assessment
  
//       Object.entries(healthKeywords).forEach(([condition, keywords]) => {
//         const response = healthAssessment[condition];
//         console.log(`Condition: ${condition}, Response:`, response); // Log condition and response
  
//         if (response) {
//           const values = Array.isArray(response) ? response : [response];
//           values.forEach((value) => {
//             console.log(`Checking value: ${value}`); // Log each value
//             if (value && typeof value === 'string') {
//               keywords.forEach((keyword) => {
//                 console.log(`Checking if "${value}" contains keyword "${keyword}"`); // Log keyword matching
//                 if (value.toLowerCase().includes(keyword.toLowerCase())) {
//                   conditionPrevalence[condition] = (conditionPrevalence[condition] || 0) + 1;
//                 }
//               });
//             }
//           });
//         }
//       });
//     });
  
//     console.log("Final Condition Prevalence:", conditionPrevalence); // Log final condition prevalence
//     return conditionPrevalence;
//   };
  
//   const calculateRiskLevels = (employees) => {
//     return employees.map((emp) => {
//       const { bp, diabetes, cholesterol } = JSON.parse(emp.health_assessment);
//       console.log("Health Assessment:", emp.health_assessment); // Log health assessment data
//       console.log("Blood Pressure:", bp, "Diabetes:", diabetes, "Cholesterol:", cholesterol); // Log values
  
//       let risk = 0;
//       if (bp && bp >= 130) risk += 2;
//       if (diabetes && diabetes >= 126) risk += 2;
//       if (cholesterol && cholesterol >= 240) risk += 1;
//       console.log("Calculated Risk Level:", risk); // Log calculated risk level
  
//       return risk;
//     });
//   };
  

//   const calculateAgeDistribution = (employees) => {
//     const ageDistribution = {
//       "<25": 0,
//       "25-34": 0,
//       "35-44": 0,
//       "45-54": 0,
//       "55+": 0,
//     };
  
//     employees.forEach((emp) => {
//       const birthDate = new Date(JSON.parse(emp.employee_info).birthDate);
//       const age = new Date().getFullYear() - birthDate.getFullYear();
//       console.log("Employee Birth Date:", birthDate, "Age:", age); // Log birth date and age
  
//       if (age < 25) ageDistribution["<25"]++;
//       else if (age < 35) ageDistribution["25-34"]++;
//       else if (age < 45) ageDistribution["35-44"]++;
//       else if (age < 55) ageDistribution["45-54"]++;
//       else ageDistribution["55+"]++;
//     });
  
//     console.log("Final Age Distribution:", ageDistribution); // Log final age distribution
//     return ageDistribution;
//   };
  

//   const calculateHealthMetrics = (employees) => {
//     const healthMetrics = {
//       bpCategories: { normal: 0, elevated: 0, stage1: 0, stage2: 0, hypertensiveCrisis: 0 },
//       diabetesCategories: { low: 0, moderate: 0, high: 0 },
//       cholesterolCategories: { normal: 0, borderline: 0, high: 0 },
//     };
  
//     employees.forEach((emp) => {
//       const { bp, diabetes, cholesterol } = JSON.parse(emp.health_assessment);
//       console.log("Health Metrics - BP:", bp, "Diabetes:", diabetes, "Cholesterol:", cholesterol); // Log values
  
//       // Blood Pressure categories
//       if (bp) {
//         if (bp < 120) healthMetrics.bpCategories.normal++;
//         else if (bp < 130) healthMetrics.bpCategories.elevated++;
//         else if (bp < 140) healthMetrics.bpCategories.stage1++;
//         else if (bp < 180) healthMetrics.bpCategories.stage2++;
//         else healthMetrics.bpCategories.hypertensiveCrisis++;
//       }
  
//       // Diabetes categories
//       if (diabetes) {
//         if (diabetes < 100) healthMetrics.diabetesCategories.low++;
//         else if (diabetes < 126) healthMetrics.diabetesCategories.moderate++;
//         else healthMetrics.diabetesCategories.high++;
//       }
  
//       // Cholesterol categories
//       if (cholesterol) {
//         if (cholesterol < 200) healthMetrics.cholesterolCategories.normal++;
//         else if (cholesterol < 240) healthMetrics.cholesterolCategories.borderline++;
//         else healthMetrics.cholesterolCategories.high++;
//       }
//     });
  
//     console.log("Final Health Metrics:", healthMetrics); // Log final health metrics
//     return healthMetrics;
//   };
  

// const calculateRiskSummary = (riskLevels) => {
//   return {
//     low: riskLevels.filter((risk) => risk <= 2).length,
//     moderate: riskLevels.filter((risk) => risk > 2 && risk <= 4).length,
//     high: riskLevels.filter((risk) => risk > 4).length,
//   };
// };

// // const getReportData = async (slug) => {
// //   try {
// //     const [companyResult] = await db.query("SELECT * FROM companies WHERE url = ?", [slug]);
// //     if (companyResult.length === 0) throw new Error("Company not found");
// //     const company = companyResult[0];

// //     const [employeeResult] = await db.query("SELECT * FROM assessment_response WHERE company_slug = ?", [slug]);
// //     if (employeeResult.length === 0) throw new Error("No employees found for the company");

// //     const totalEmployees = employeeResult.length;
// //     const MaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).Gender === "male").length;
// //     const FemaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).Gender === "female").length;

// //     const ageDistribution = calculateAgeDistribution(employeeResult);
// //     const bmiData = calculateBMI(employeeResult);
// //     const conditionPrevalence = calculateConditionPrevalence(employeeResult);
// //     const riskLevels = calculateRiskLevels(employeeResult);
// //     const riskSummary = calculateRiskSummary(riskLevels);
// //     const healthMetrics = calculateHealthMetrics(employeeResult);

// //     return {
// //       company: {
// //         name: company.name,
// //         totalEmployees,
// //         MaleEmployees,
// //         FemaleEmployees,
// //         conditionPrevalence,
// //         ageDistribution,
// //         bmiData,
// //         riskSummary,
// //         healthMetrics,
// //       },
// //     };
// //   } catch (error) {
// //     logger.error("Error fetching report data:", error);
// //     throw new Error("Error fetching report data");
// //   }
// // };
// const calculateWomanHealthRiskScore = (employees) => {
//     const riskScoreData = {
//       reproductiveHealth: { low: 0, moderate: 0, high: 0 },
//       osteoporosisRisk: { low: 0, moderate: 0, high: 0 },
//       menopauseRelatedRisk: { low: 0, moderate: 0, high: 0 },
//     };
  
//     employees.forEach((emp) => {
//       const healthAssessment = JSON.parse(emp.health_assessment);
  
//       // Reproductive health risk
//       const reproductiveRiskScore = healthAssessment.reproductiveHealthRiskScore;
//       console.log("Reproductive Health Risk Score:", reproductiveRiskScore); // Log reproductive health score
//       if (reproductiveRiskScore <= 100) riskScoreData.reproductiveHealth.low++;
//       else if (reproductiveRiskScore <= 200) riskScoreData.reproductiveHealth.moderate++;
//       else riskScoreData.reproductiveHealth.high++;
  
//       // Osteoporosis risk
//       const osteoporosisRiskScore = healthAssessment.osteoporosisRiskScore;
//       console.log("Osteoporosis Risk Score:", osteoporosisRiskScore); // Log osteoporosis risk score
//       if (osteoporosisRiskScore <= 50) riskScoreData.osteoporosisRisk.low++;
//       else if (osteoporosisRiskScore <= 100) riskScoreData.osteoporosisRisk.moderate++;
//       else riskScoreData.osteoporosisRisk.high++;
  
//       // Menopause-related risk
//       const menopauseRiskScore = healthAssessment.menopauseRiskScore;
//       console.log("Menopause Risk Score:", menopauseRiskScore); // Log menopause risk score
//       if (menopauseRiskScore <= 70) riskScoreData.menopauseRelatedRisk.low++;
//       else if (menopauseRiskScore <= 140) riskScoreData.menopauseRelatedRisk.moderate++;
//       else riskScoreData.menopauseRelatedRisk.high++;
//     });
  
//     console.log("Final Woman Health Risk Scores:", riskScoreData); // Log final woman health risk score data
//     return riskScoreData;
//   };
  
//   const calculateBenefitCoverage = (employees) => {
//     const benefitCoverage = { covered: 0, notCovered: 0 };
    
//     employees.forEach((emp) => {
//       if (emp.benefit_info) {
//         try {
//           const benefitData = JSON.parse(emp.benefit_info);
//           console.log("Benefit Data:", benefitData); // Log benefit data
//           if (benefitData.covered) benefitCoverage.covered++;
//           else benefitCoverage.notCovered++;
//         } catch (error) {
//           console.error("Error parsing benefit data for employee:", emp);
//         }
//       }
//     });
  
//     console.log("Final Benefit Coverage:", benefitCoverage); // Log final benefit coverage
//     return benefitCoverage;
//   };
  
  
//   const calculateSatisfactionLevels = (employees) => {
//     const satisfactionLevels = { veryDissatisfied: 0, dissatisfied: 0, neutral: 0, satisfied: 0, verySatisfied: 0 };

//   employees.forEach((emp) => {
//     const satisfaction = emp.satisfaction_level;
//     console.log("Employee Satisfaction Level:", satisfaction); // Log satisfaction level
//     switch (satisfaction) {
//       case 1: satisfactionLevels.veryDissatisfied++; break;
//       case 2: satisfactionLevels.dissatisfied++; break;
//       case 3: satisfactionLevels.neutral++; break;
//       case 4: satisfactionLevels.satisfied++; break;
//       case 5: satisfactionLevels.verySatisfied++; break;
//     }
//   });

//   console.log("Final Satisfaction Levels:", satisfactionLevels); // Log satisfaction levels
//   return satisfactionLevels;

    
//     employees.forEach((emp) => {
//       if (emp.satisfaction_info) {
//         try {
//           const satisfactionData = JSON.parse(emp.satisfaction_info);
//           if (satisfactionData.isSatisfied) satisfactionLevels.satisfied++;
//           else satisfactionLevels.unsatisfied++;
//         } catch (error) {
//           console.error("Invalid JSON in satisfaction_info:", error);
//         }
//       }
//     });
    
//     return satisfactionLevels;
//   };
  
//   const calculateTotalPoints = (employees) => {
//     const totalPointsData = {
//       totalPoints: 0,
//       maxPoints: 400,
//       averagePoints: 0,
//       pointsAchievedPercentage: 0,
//     };
  
//     let employeeCount = 0;
  
//     employees.forEach((emp) => {
//       if (emp.points_info) {
//         try {
//           const pointsData = JSON.parse(emp.points_info);
//           const points = pointsData.total;
  
//           if (typeof points === 'number' && !isNaN(points)) {
//             totalPointsData.totalPoints += points;
//             employeeCount++;
//           } else {
//             console.warn(`Invalid 'total' value for employee:`, emp);
//           }
//         } catch (error) {
//           console.error("Invalid JSON in points_info for employee:", emp, error);
//         }
//       } else {
//         console.warn(`No points_info provided for employee:`, emp);
//       }
//     });
  
//     // Calculate average points per employee
//     if (employeeCount > 0) {
//       totalPointsData.averagePoints = totalPointsData.totalPoints / employeeCount;
//     }
  
//     // Calculate percentage of total points achieved relative to max points
//     totalPointsData.pointsAchievedPercentage = (totalPointsData.totalPoints / (employeeCount * totalPointsData.maxPoints)) * 100;
  
//     return totalPointsData;
//   };
  
  
//   const getReportData = async (slug) => {
//     try {
//       const [companyResult] = await db.query("SELECT * FROM companies WHERE url = ?", [slug]);
//       if (companyResult.length === 0) throw new Error("Company not found");
//       const company = companyResult[0];
  
//       const [employeeResult] = await db.query("SELECT * FROM assessment_response WHERE company_slug = ?", [slug]);
//       if (employeeResult.length === 0) throw new Error("No employees found for the company");
  
//       const totalEmployees = employeeResult.length;
//       const MaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).Gender === "male").length;
//       const FemaleEmployees = employeeResult.filter((emp) => JSON.parse(emp.employee_info).Gender === "female").length;
  
//       const ageDistribution = calculateAgeDistribution(employeeResult);
//       const bmiData = calculateBMI(employeeResult);
//       const conditionPrevalence = calculateConditionPrevalence(employeeResult);
//       const riskLevels = calculateRiskLevels(employeeResult);
//       const riskSummary = calculateRiskSummary(riskLevels);
//       const healthMetrics = calculateHealthMetrics(employeeResult);
//       const WomanHealthRiskScore = calculateWomanHealthRiskScore(employeeResult);
//       const benefitCoverage = calculateBenefitCoverage(employeeResult);
//       const satisfactionLevels = calculateSatisfactionLevels(employeeResult);
//       const totalPointsData = calculateTotalPoints(employeeResult);
  
//       return {
//         company: {
//           name: company.name,
//           totalEmployees,
//           MaleEmployees,
//           FemaleEmployees,
//           conditionPrevalence,
//           ageDistribution,
//           bmiData,
//           riskSummary,
//           healthMetrics,
//           WomanHealthRiskScore,
//           benefitCoverage,
//           satisfactionLevels,
//           totalPointsData
//         },
//       };
//     } catch (error) {
//       logger.error("Error fetching report data:", error);
//       throw new Error("Error fetching report data");
//     }
//   };
  
// const generatePdfReport = async (slug, reportData) => {
//   try {
//     const company = reportData.company;
//     const reportHtml = `
//       <html>
//         <head>
//           <meta charset="UTF-8">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>${company.name} - Report</title>
//         </head>
//         <body>
//           <h1>Health Report for ${company.name}</h1>
//           <h2>Employee Statistics</h2>
//           <p>Total Employees: ${company.totalEmployees}</p>
//           <p>Male Employees: ${company.MaleEmployees}</p>
//           <p>Female Employees: ${company.FemaleEmployees}</p>
          
//           <h2>Condition Prevalence</h2>
//           <ul>${Object.entries(company.conditionPrevalence).map(([condition, count]) => `<li>${condition}: ${count}</li>`).join("")}</ul>

//           <h2>BMI Categories</h2>
//           <ul>${Object.entries(company.bmiData).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>

//           <h2>Age Distribution</h2>
//           <ul>${Object.entries(company.ageDistribution).map(([ageRange, count]) => `<li>${ageRange}: ${count}</li>`).join("")}</ul>

//           <h2>Risk Summary</h2>
//           <ul>
//             <li>Low Risk: ${company.riskSummary.low}</li>
//             <li>Moderate Risk: ${company.riskSummary.moderate}</li>
//             <li>High Risk: ${company.riskSummary.high}</li>
//           </ul>

//           <h2>Health Metrics</h2>
//           <p>Blood Pressure Categories:</p>
//           <ul>${Object.entries(company.healthMetrics.bpCategories).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>

//           <p>Diabetes Categories:</p>
//           <ul>${Object.entries(company.healthMetrics.diabetesCategories).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>

//           <p>Cholesterol Categories:</p>
//           <ul>${Object.entries(company.healthMetrics.cholesterolCategories).map(([category, count]) => `<li>${category}: ${count}</li>`).join("")}</ul>
//         </body>
//       </html>`;

//     const browser = await puppeteer.launch();
//     const page = await browser.newPage();
//     await page.setContent(reportHtml);
//     const filePath = path.join(__dirname, "../reports", `${slug}-report.pdf`);
//     await page.pdf({ path: filePath });
//     await browser.close();
//     return filePath;
//   } catch (error) {
//     logger.error("Error generating PDF report:", error);
//     throw new Error("Error generating PDF report");
//   }
// };

// module.exports = {
//   getReportData,
//   generatePdfReport,
// };

// // const express = require("express");
// // const router = express.Router();
// // const db = require("../config/db");
// // const axios = require("axios");
// // const puppeteer = require("puppeteer");
// // const logger = require("../utils/logger");
// // const {
// //   calculateBMI,
// //   calculateAgeDistribution,
// //   calculateRisk,
// //   calculateBenefitCoverageSatisfaction,
// // } = require("../utils/helpers");

// // // Health condition keywords for prevalence calculation
// // const healthKeywords = {
// //   "Rheumatoid Arthritis": ["arthritis", "joint pain"],
// //   Diabetes: ["diabetes", "high blood sugar"],
// //   "Hypertension (High BP)": ["hypertension", "high blood pressure"],
// //   "High Cholesterol": ["cholesterol"],
// //   Gout: ["gout"],
// //   Anemia: ["anemia"],
// //   Fibromyalgia: ["fibromyalgia"],
// //   COPD: ["lung disease", "COPD"],
// //   "Metabolic Disorder": ["metabolic disorder"],
// //   "Thyroid Disease": ["thyroid"],
// //   "Cardiovascular Disease": ["heart disease", "cardiovascular"],
// //   Asthma: ["asthma"],
// //   Osteoporosis: ["osteoporosis"],
// //   "Chronic Kidney Disease": ["kidney disease"],
// //   "Urogenital Disease": ["urogenital"],
// // };

// // // Function to interpret BP, Diabetes, and Cholesterol levels
// // function interpretHealthMetrics(employeeData) {
// //   const bpCategories = {
// //     normal: 0,
// //     elevated: 0,
// //     stage1: 0,
// //     stage2: 0,
// //     hypertensiveCrisis: 0,
// //   };
// //   const diabetesCategories = { low: 0, moderate: 0, high: 0 };
// //   const cholesterolCategories = { normal: 0, borderline: 0, high: 0 };

// //   employeeData.forEach((emp) => {
// //     const healthAssessment = JSON.parse(emp.health_assessment);
// //     const { bp, diabetes, cholesterol } = healthAssessment;

// //     // BP interpretation
// //     if (bp) {
// //       if (bp < 120) bpCategories.normal++;
// //       else if (bp >= 120 && bp < 130) bpCategories.elevated++;
// //       else if (bp >= 130 && bp < 140) bpCategories.stage1++;
// //       else if (bp >= 140 && bp < 180) bpCategories.stage2++;
// //       else if (bp >= 180) bpCategories.hypertensiveCrisis++;
// //     }

// //     // Diabetes interpretation
// //     if (diabetes) {
// //       if (diabetes < 100) diabetesCategories.low++;
// //       else if (diabetes >= 100 && diabetes < 126) diabetesCategories.moderate++;
// //       else if (diabetes >= 126) diabetesCategories.high++;
// //     }

// //     // Cholesterol interpretation
// //     if (cholesterol) {
// //       if (cholesterol < 200) cholesterolCategories.normal++;
// //       else if (cholesterol >= 200 && cholesterol < 240) cholesterolCategories.borderline++;
// //       else if (cholesterol >= 240) cholesterolCategories.high++;
// //     }
// //   });

// //   return { bpCategories, diabetesCategories, cholesterolCategories };
// // }

// // // Function to calculate service utilization and coverage
// // function calculateServiceUtilization(employeeData, serviceKeywords) {
// //   const utilization = {};
// //   const coverage = {};

// //   employeeData.forEach((emp) => {
// //     const services = JSON.parse(emp.services_used); // Assuming `services_used` is stored in the DB
// //     Object.keys(serviceKeywords).forEach((service) => {
// //       if (services.includes(service)) {
// //         utilization[service] = (utilization[service] || 0) + 1;
// //       }
// //       coverage[service] = serviceKeywords[service]; // Assuming coverage percentage is in serviceKeywords
// //     });
// //   });

// //   // Convert counts to percentages for utilization
// //   const totalEmployees = employeeData.length;
// //   Object.keys(utilization).forEach((service) => {
// //     utilization[service] = ((utilization[service] / totalEmployees) * 100).toFixed(2);
// //   });

// //   return { utilization, coverage };
// // }

// // // Additional service coverage data for calculation
// // const serviceKeywords = {
// //   Telemedicine: 20,
// //   OPD: 15,
// //   IPD: 15,
// //   Pharmacy: 20,
// //   "Lab And Diagnostics": 20,
// //   Homecare: 20,
// //   Maternity: 20,
// //   "Dental Procedure": 20,
// //   "Pre-Existing Condition": 20,
// //   "Wellness Program And Preventive Care": 20,
// // };

// // // Calculate health conditions prevalence
// // function calculateHealthConditionsPrevalence(employeeData, healthKeywords) {
// //   const conditionPrevalence = {};

// //   employeeData.forEach((emp) => {
// //     const healthAssessment = JSON.parse(emp.health_assessment);
    
// //     Object.entries(healthKeywords).forEach(([condition, keywords]) => {
// //       const response = healthAssessment[condition];

// //       if (response) {
// //         if (Array.isArray(response)) {
// //           if (response.some((value) => keywords.some((keyword) => value.toLowerCase().includes(keyword.toLowerCase())))) {
// //             conditionPrevalence[condition] = (conditionPrevalence[condition] || 0) + 1;
// //           }
// //         } else if (typeof response === 'string') {
// //           if (keywords.some((keyword) => response.toLowerCase().includes(keyword.toLowerCase()))) {
// //             conditionPrevalence[condition] = (conditionPrevalence[condition] || 0) + 1;
// //           }
// //         }
// //       }
// //     });
// //   });

// //   const totalEmployees = employeeData.length;
// //   Object.keys(conditionPrevalence).forEach((condition) => {
// //     const count = conditionPrevalence[condition];
// //     conditionPrevalence[condition] = ((count / totalEmployees) * 100).toFixed(2);
// //   });

// //   return conditionPrevalence;
// // }

// // // Route to generate a company report (including health condition prevalence, BMI, age distribution, etc.)
// // router.get("/companies/:slug/report-calculation", async (req, res) => {
// //   const { slug } = req.params;

// //   try {
// //     // Fetch the company by slug from the database
// //     const [companyResult] = await db.query(
// //       "SELECT * FROM companies WHERE url = ?",
// //       [slug]
// //     );
// //     if (companyResult.length === 0) {
// //       return res.status(404).json({ error: "Company not found" });
// //     }
// //     const company = companyResult[0];

// //     // Fetch employee data and their assessment responses
// //     const [employeeResult] = await db.query(
// //       "SELECT * FROM employees WHERE company_id = ?",
// //       [company.id]
// //     );

// //     const totalEmployees = employeeResult.length;
// //     const maleEmployees = employeeResult.filter(
// //       (emp) => JSON.parse(emp.employee_info).gender === "Male"
// //     ).length;
// //     const femaleEmployees = employeeResult.filter(
// //       (emp) => JSON.parse(emp.employee_info).gender === "Female"
// //     ).length;

// //     // Age distribution calculation
// //     const ageDistribution = calculateAgeDistribution(employeeResult);

// //     // BMI categorization and count
// //     const bmiData = {
// //       "Below Normal Weight": 0,
// //       "Normal Weight": 0,
// //       "Overweight": 0,
// //       "Class I Obesity": 0,
// //       "Class II Obesity": 0,
// //       "Class III Obesity": 0
// //     };

// //     employeeResult.forEach((emp) => {
// //       const employeeInfo = JSON.parse(emp.employee_info);
// //       const weight = employeeInfo.weight;
// //       const height = employeeInfo.height;

// //       if (weight && height) {
// //         const heightInMeters = height / 100;
// //         const bmi = weight / Math.pow(heightInMeters, 2);

// //         let category = "Below Normal Weight";
// //         if (bmi >= 18.5 && bmi <= 24.9) {
// //           category = "Normal Weight";
// //         } else if (bmi >= 25 && bmi <= 29.9) {
// //           category = "Overweight";
// //         } else if (bmi >= 30 && bmi <= 34.9) {
// //           category = "Class I Obesity";
// //         } else if (bmi >= 35 && bmi <= 39.9) {
// //           category = "Class II Obesity";
// //         } else if (bmi >= 40) {
// //           category = "Class III Obesity";
// //         }

// //         bmiData[category]++;
// //       }
// //     });

// //     // Calculate risk levels for employees
// //     const riskLevels = employeeResult.map((emp) => {
// //       const healthAssessment = JSON.parse(emp.health_assessment);
// //       return calculateRisk(healthAssessment);
// //     });

// //     // Calculate health condition prevalence
// //     const conditionPrevalence = calculateHealthConditionsPrevalence(
// //       employeeResult,
// //       healthKeywords
// //     );

// //     // Satisfaction with benefits
// //     const benefitCoverage = calculateBenefitCoverageSatisfaction(employeeResult);

// //     // Health metrics (Blood Pressure, Diabetes, Cholesterol)
// //     const healthMetrics = interpretHealthMetrics(employeeResult);

// //     // Female employee health (gynecological conditions and pregnancy plans)
// //     const femaleHealthData = employeeResult
// //       .filter((emp) => JSON.parse(emp.employee_info).gender === "Female")
// //       .map((emp) => {
// //         const response = JSON.parse(emp.health_assessment);
// //         return {
// //           gynecologicalCondition: response.gynecologicalCondition,
// //           pregnancyPlans: response.pregnancyPlans,
// //         };
// //       });

// //     // Calculate service utilization
// //     const serviceData = calculateServiceUtilization(employeeResult, serviceKeywords);

// //     // Return the calculated report data as JSON
// //     res.json({
// //       company: {
// //         name: company.name,
// //         totalEmployees,
// //         maleEmployees,
// //         femaleEmployees,
// //         conditionPrevalence,
// //         ageDistribution,
// //         bmiData,
// //         riskLevels,
// //         healthMetrics,
// //         benefitCoverage,
// //         femaleHealthData,
// //         serviceData,
// //       },
// //     });
// //   } catch (error) {
// //     logger.error("Error generating report:", error);
// //     res.status(500).json({ error: "Internal server error" });
// //   }
// // });
// const express = require("express");
// const router = express.Router();
// const db = require("../config/db");
// const logger = require("../utils/logger");

// const healthKeywords = {
//   "Rheumatoid Arthritis": ["arthritis", "joint pain"],
//   Diabetes: ["diabetes", "high blood sugar"],
//   "Hypertension (High BP)": ["hypertension", "high blood pressure"],
//   "High Cholesterol": ["cholesterol"],
//   Gout: ["gout"],
//   Anemia: ["anemia"],
//   Fibromyalgia: ["fibromyalgia"],
//   COPD: ["lung disease", "COPD"],
//   "Metabolic Disorder": ["metabolic disorder"],
//   "Thyroid Disease": ["thyroid"],
//   "Cardiovascular Disease": ["heart disease", "cardiovascular"],
//   Asthma: ["asthma"],
//   Osteoporosis: ["osteoporosis"],
//   "Chronic Kidney Disease": ["kidney disease"],
//   "Urogenital Disease": ["urogenital"],
// };

// const calculateBMI = (employees) => {
//   const bmiData = {
//     "Below-Normal-Weight": 0,
//     "Normal-Weight": 0,
//     "Overweight": 0,
//     "Class-I-Obesity": 0,
//     "Class-II-Obesity": 0,
//     "Class-III-Obesity": 0,
//   };

//   employees.forEach((emp) => {
//     const employeeInfo = JSON.parse(emp.employee_info);
//     const weight = employeeInfo.weight;
//     const height = employeeInfo.height;

//     if (weight && height) {
//       const heightInMeters = height / 100;
//       const bmi = weight / Math.pow(heightInMeters, 2);

//       let category = "Below-Normal-Weight";
//       if (bmi >= 18.5 && bmi <= 24.9) {
//         category = "Normal-Weight";
//       } else if (bmi >= 25 && bmi <= 29.9) {
//         category = "Overweight";
//       } else if (bmi >= 30 && bmi <= 34.9) {
//         category = "Class-I-Obesity";
//       } else if (bmi >= 35 && bmi <= 39.9) {
//         category = "Class-II-Obesity";
//       } else if (bmi >= 40) {
//         category = "Class-III-Obesity";
//       }

//       bmiData[category]++;
//     }
//   });

//   return bmiData;
// };

// const calculateConditionPrevalence = (employees) => {
//   const conditionPrevalence = {};

//   employees.forEach((emp) => {
//     const healthAssessment = JSON.parse(emp.health_assessment);

//     Object.entries(healthKeywords).forEach(([condition, keywords]) => {
//       const response = healthAssessment[condition];

//       if (response) {
//         if (Array.isArray(response)) {
//           if (response.some((value) => keywords.some((keyword) => value.toLowerCase().includes(keyword.toLowerCase())))) {
//             conditionPrevalence[condition] = (conditionPrevalence[condition] || 0) + 1;
//           }
//         } else if (typeof response === 'string') {
//           if (keywords.some((keyword) => response.toLowerCase().includes(keyword.toLowerCase()))) {
//             conditionPrevalence[condition] = (conditionPrevalence[condition] || 0) + 1;
//           }
//         }
//       }
//     });
//   });

//   return conditionPrevalence;
// };

// const calculateRiskLevels = (employees) => {
//   return employees.map((emp) => {
//     const healthAssessment = JSON.parse(emp.health_assessment);
//     const { bp, diabetes, cholesterol } = healthAssessment;

//     let risk = 0;

//     if (bp && bp >= 130) risk += 2; 
//     if (diabetes && diabetes >= 126) risk += 2; 
//     if (cholesterol && cholesterol >= 240) risk += 1; 

//     return risk;
//   });
// };

// const calculateAgeDistribution = (employees) => {
//   const ageDistribution = {
//     "<25": 0,
//     "25-34": 0,
//     "35-44": 0,
//     "45-54": 0,
//     "55+": 0,
//   };

//   employees.forEach((emp) => {
//     const birthDate = JSON.parse(emp.employee_info).birthDate;
//     const age = new Date().getFullYear() - new Date(birthDate).getFullYear();

//     if (age < 25) ageDistribution["<25"]++;
//     else if (age >= 25 && age < 35) ageDistribution["25-34"]++;
//     else if (age >= 35 && age < 45) ageDistribution["35-44"]++;
//     else if (age >= 45 && age < 55) ageDistribution["45-54"]++;
//     else ageDistribution["55+"]++;
//   });

//   return ageDistribution;
// };

// const calculateHealthMetrics = (employees) => {
//   const healthMetrics = {
//     bpCategories: {
//       normal: 0,
//       elevated: 0,
//       stage1: 0,
//       stage2: 0,
//       hypertensiveCrisis: 0,
//     },
//     diabetesCategories: { low: 0, moderate: 0, high: 0 },
//     cholesterolCategories: { normal: 0, borderline: 0, high: 0 },
//   };

//   employees.forEach((emp) => {
//     const healthAssessment = JSON.parse(emp.health_assessment);
//     const { bp, diabetes, cholesterol } = healthAssessment;

//     if (bp) {
//       if (bp < 120) healthMetrics.bpCategories.normal++;
//       else if (bp >= 120 && bp < 130) healthMetrics.bpCategories.elevated++;
//       else if (bp >= 130 && bp < 140) healthMetrics.bpCategories.stage1++;
//       else if (bp >= 140 && bp < 180) healthMetrics.bpCategories.stage2++;
//       else if (bp >= 180) healthMetrics.bpCategories.hypertensiveCrisis++;
//     }

//     if (diabetes) {
//       if (diabetes < 100) healthMetrics.diabetesCategories.low++;
//       else if (diabetes >= 100 && diabetes < 126) healthMetrics.diabetesCategories.moderate++;
//       else if (diabetes >= 126) healthMetrics.diabetesCategories.high++;
//     }

//     if (cholesterol) {
//       if (cholesterol < 200) healthMetrics.cholesterolCategories.normal++;
//       else if (cholesterol >= 200 && cholesterol < 240) healthMetrics.cholesterolCategories.borderline++;
//       else if (cholesterol >= 240) healthMetrics.cholesterolCategories.high++;
//     }
//   });

//   return healthMetrics;
// };

// router.get("/companies/:slug/report-calculation", async (req, res) => {
//   const { slug } = req.params;

//   try {
//     const [companyResult] = await db.query("SELECT * FROM companies WHERE url = ?", [slug]);
//     if (companyResult.length === 0) {
//       return res.status(404).json({ error: "Company not found" });
//     }
//     const company = companyResult[0];

//     const [employeeResult] = await db.query("SELECT * FROM employees WHERE company_id = ?", [company.id]);
//     if (employeeResult.length === 0) {
//       return res.status(404).json({ error: "No employees found for the company" });
//     }

//     const totalEmployees = employeeResult.length;
//     const MaleEmployees = employeeResult.filter(
//       (emp) => JSON.parse(emp.employee_info).Gender.toLowerCase() === "Male"
//     ).length;
//     const FemaleEmployees = employeeResult.filter(
//       (emp) => JSON.parse(emp.employee_info).Gender.toLowerCase() === "Female"
//     ).length;

//     const ageDistribution = calculateAgeDistribution(employeeResult);
//     const bmiData = calculateBMI(employeeResult);
//     const conditionPrevalence = calculateConditionPrevalence(employeeResult);
//     const riskLevels = calculateRiskLevels(employeeResult);
//     const healthMetrics = calculateHealthMetrics(employeeResult);

//     res.json({
//       company: {
//         name: company.name,
//         totalEmployees,
//         MaleEmployees,
//         FemaleEmployees,
//         conditionPrevalence, 
//         ageDistribution,
//         bmiData,
//         riskLevels,
//         healthMetrics,
//       },
//     });
//   } catch (error) {
//     logger.error("Error generating report:", error);
//     res.status(500).json({ error: "Internal server error" });
//   }
// });

// router.get("/companies/:slug/report-pdf", async (req, res) => {
//   const { slug } = req.params;

//   try {
//     const reportDataResponse = await axios.get(
//       `http://localhost:5000/api/companies/${slug}/report-calculation`
//     );
//     const reportData = reportDataResponse.data;

//     if (!reportData) {
//       return res.status(404).json({ error: "Report data not found" });
//     }

//     const company = reportData.company;

//     const reportHtml = `
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//           <meta charset="UTF-8">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Report for ${company.name}</title>
//       </head>
//       <body>
//           <h1>${company.name} Health Report</h1>
//           <h2>Total Employees: ${company.totalEmployees}</h2>
//           <h3>Gender Distribution:</h3>
//           <p>Males: ${company.MaleEmployees}, Females: ${company.FemaleEmployees}</p>
//           <h3>Age Distribution:</h3>
//           <ul>
//             ${Object.entries(company.ageDistribution).map(
//               ([ageGroup, count]) => `<li>${ageGroup}: ${count}</li>`
//             ).join("")}
//           </ul>
//           <h3>BMI Categories:</h3>
//           <ul>
//             ${Object.entries(company.bmiData).map(
//               ([category, count]) => `<li>${category}: ${count}</li>`
//             ).join("")}
//           </ul>
//           <h3>Health Conditions Prevalence:</h3>
//           <ul>
//             ${Object.entries(company.conditionPrevalence).map(
//               ([condition, count]) => `<li>${condition}: ${count}</li>`
//             ).join("")}
//           </ul>
//           <h3>Health Metrics:</h3>
//           <p>Blood Pressure Categories: ${JSON.stringify(company.healthMetrics.bpCategories)}</p>
//           <p>Diabetes Categories: ${JSON.stringify(company.healthMetrics.diabetesCategories)}</p>
//           <p>Cholesterol Categories: ${JSON.stringify(company.healthMetrics.cholesterolCategories)}</p>
//       </body>
//       </html>`;

//     const browser = await puppeteer.launch();
//     const page = await browser.newPage();
//     await page.setContent(reportHtml);
//     const pdfBuffer = await page.pdf({ format: "A4" });
//     await browser.close();

//     const filePath = `public/reports/report_${slug}.pdf`;
//     fs.writeFileSync(filePath, pdfBuffer);

//     res.json({ file: `/reports/report_${slug}.pdf` });
//   } catch (error) {
//     logger.error("Error generating PDF:", error);
//     res.status(500).json({ error: "Failed to generate PDF" });
//   }
// });

// module.exports = router;

const express = require("express");
const router = express.Router();
const { getReportData, generatePdfReport } = require("../controllers/CompanyCalculationsController");

// Route to get the report data (JSON response)
router.get("/company-calculation/companies/:slug/report-calculation", async (req, res) => {
  try {
    const reportData = await getReportData(req.params.slug);
    res.status(200).json(reportData);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Route to generate and download PDF report
router.get("/company-calculation/companies/:slug/report-calculation/pdf", async (req, res) => {
  try {
    const reportData = await getReportData(req.params.slug);
    const filePath = await generatePdfReport(req.params.slug, reportData);
    res.download(filePath);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;

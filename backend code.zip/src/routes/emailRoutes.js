const express = require('express');
const router = express.Router();
const { sendCompanyCreationEmail, sendUserSubmissionEmail, sendCompanyReportEmail } = require('../controllers/emailController');

// 1. Send company creation email
router.post('/sendCompanyCreationEmail', async (req, res) => {
  const { companyName, companySlug, companyEmail } = req.body;
  try {
    await sendCompanyCreationEmail(companyName, companySlug, companyEmail);
    res.status(200).json({ message: 'Company creation email sent successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send company creation email' });
  }
});

// 2. Send user submission email
router.post('/sendUserSubmissionEmail', async (req, res) => {
  const { userEmail, userData } = req.body;  // userData contains BMI, marks, etc.
  try {
    await sendUserSubmissionEmail(userEmail, userData);
    res.status(200).json({ message: 'User submission email sent successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send user submission email' });
  }
});

// 3. Send company report email
router.post('/sendCompanyReportEmail', async (req, res) => {
  const { companyEmail, companyName, reportLink } = req.body;
  try {
    await sendCompanyReportEmail(companyEmail, companyName, reportLink);
    res.status(200).json({ message: 'Company report email sent successfully!' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send company report email' });
  }
});

module.exports = router;
